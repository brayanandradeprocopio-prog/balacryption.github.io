export type CardType = 
  | "fire" 
  | "water" 
  | "plant" 
  | "shadow" 
  | "light" 
  | "electric" 
  | "ice" 
  | "poison" 
  | "metal" 
  | "spirit";

export type CardRarity = "common" | "rare" | "epic" | "legendary" | "cursed";

export type EffectCondition = 
  | "on_play"
  | "on_death"
  | "on_sacrifice"
  | "on_attack"
  | "on_defend"
  | "start_turn"
  | "vs_type";

export interface CardEffect {
  condition: EffectCondition;
  description: string;
  modifier?: {
    attack?: number;
    defense?: number;
    targetType?: CardType;
  };
}

export interface Card {
  id: string;
  name: string;
  type: CardType;
  attack: number;
  defense: number;
  level: number;
  rarity: CardRarity;
  cost: number; // Sacrifice cost
  effects: CardEffect[];
  description: string;
  imageUrl?: string;
  isSacrificing?: boolean; // Visual marker for sacrifice animation
}

export interface PlayerDeck {
  id: string;
  userId: string;
  name: string;
  cards: Card[];
  createdAt: string;
}

export interface FieldToken {
  id: string;
  name: string;
  type: "nerf" | "debuff";
  targetElement?: CardType;
  effect: string;
  description: string;
}

export interface BattleState {
  id: string;
  playerHealth: number;
  opponentHealth: number;
  playerBoard: (Card | null)[];
  opponentBoard: (Card | null)[];
  playerHand: Card[];
  currentTurn: "player" | "opponent";
  roundNumber: number;
}

export interface PlayerProgress {
  id: string;
  userId: string;
  level: number;
  experience: number;
  wins: number;
  losses: number;
  unlockedCards: string[];
  deckCapacity: number;
}
