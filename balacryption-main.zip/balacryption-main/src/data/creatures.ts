import { Card, CardType } from "@/types/card";

// Generate 60 unique creature cards with different types, stats, and effects
export const CREATURE_CARDS: Omit<Card, "id">[] = [
  // FIRE TYPE (10 cards)
  {
    name: "Chama Iniciante",
    type: "fire",
    attack: 2,
    defense: 1,
    level: 1,
    rarity: "common",
    cost: 0,
    effects: [],
    description: "Uma pequena chama que começa a despertar."
  },
  {
    name: "Lobo de Brasas",
    type: "fire",
    attack: 4,
    defense: 3,
    level: 3,
    rarity: "common",
    cost: 1,
    effects: [{ condition: "vs_type", description: "+2 ATK vs Planta", modifier: { attack: 2, targetType: "plant" } }],
    description: "Caçador das florestas em chamas."
  },
  {
    name: "Dragão Menor",
    type: "fire",
    attack: 6,
    defense: 4,
    level: 5,
    rarity: "rare",
    cost: 2,
    effects: [
      { condition: "on_attack", description: "Causa 1 de dano direto", modifier: { attack: 1 } },
      { condition: "vs_type", description: "+3 ATK vs Planta", modifier: { attack: 3, targetType: "plant" } }
    ],
    description: "O sopro de fogo não conhece piedade."
  },
  {
    name: "Fênix Renascida",
    type: "fire",
    attack: 5,
    defense: 5,
    level: 7,
    rarity: "epic",
    cost: 2,
    effects: [{ condition: "on_death", description: "Retorna à mão no próximo turno" }],
    description: "Da morte, renasce em chamas."
  },
  {
    name: "Senhor do Vulcão",
    type: "fire",
    attack: 9,
    defense: 6,
    level: 9,
    rarity: "legendary",
    cost: 3,
    effects: [
      { condition: "start_turn", description: "+1 ATK para aliados de Fogo", modifier: { attack: 1 } },
      { condition: "on_play", description: "Causa 2 de dano a todos os inimigos" }
    ],
    description: "O mestre absoluto das chamas ancestrais."
  },
  {
    name: "Salamandra Ardente",
    type: "fire",
    attack: 3,
    defense: 2,
    level: 2,
    rarity: "common",
    cost: 1,
    effects: [],
    description: "Caminha sobre as brasas sem medo."
  },
  {
    name: "Meteorito Vivo",
    type: "fire",
    attack: 7,
    defense: 2,
    level: 6,
    rarity: "rare",
    cost: 2,
    effects: [{ condition: "on_play", description: "Causa 3 de dano direto mas perde 1 DEF" }],
    description: "Impacto devastador, mas frágil."
  },
  {
    name: "Ifrit Sombrio",
    type: "fire",
    attack: 8,
    defense: 5,
    level: 8,
    rarity: "epic",
    cost: 3,
    effects: [{ condition: "on_attack", description: "Inimigo perde 1 DEF permanente" }],
    description: "Chamas que consomem a própria essência."
  },
  {
    name: "Cinzas Vivas",
    type: "fire",
    attack: 1,
    defense: 1,
    level: 1,
    rarity: "common",
    cost: 0,
    effects: [{ condition: "on_death", description: "Invoca outra Cinzas Vivas" }],
    description: "Da destruição nasce mais destruição."
  },
  {
    name: "Titã Flamejante",
    type: "fire",
    attack: 10,
    defense: 8,
    level: 10,
    rarity: "legendary",
    cost: 4,
    effects: [
      { condition: "start_turn", description: "Todos os aliados ganham +2 ATK" },
      { condition: "on_play", description: "Destrói uma carta inimiga aleatória" }
    ],
    description: "A encarnação do apocalipse ígneo."
  },

  // WATER TYPE (10 cards)
  {
    name: "Gota Flutuante",
    type: "water",
    attack: 1,
    defense: 2,
    level: 1,
    rarity: "common",
    cost: 0,
    effects: [],
    description: "Pureza em forma líquida."
  },
  {
    name: "Sereia Cantora",
    type: "water",
    attack: 3,
    defense: 4,
    level: 3,
    rarity: "common",
    cost: 1,
    effects: [{ condition: "on_play", description: "Cura 2 de vida" }],
    description: "Seu canto acalma as feridas."
  },
  {
    name: "Leviatã das Profundezas",
    type: "water",
    attack: 7,
    defense: 7,
    level: 8,
    rarity: "epic",
    cost: 3,
    effects: [
      { condition: "vs_type", description: "+4 ATK vs Fogo", modifier: { attack: 4, targetType: "fire" } },
      { condition: "on_attack", description: "Inimigo não pode atacar no próximo turno" }
    ],
    description: "Das profundezas abissais, o terror emerge."
  },
  {
    name: "Maremoto",
    type: "water",
    attack: 6,
    defense: 3,
    level: 5,
    rarity: "rare",
    cost: 2,
    effects: [{ condition: "on_play", description: "Devolve todas as cartas inimigas com DEF ≤2 para a mão" }],
    description: "A força incontrolável do oceano."
  },
  {
    name: "Poseidon Corrompido",
    type: "water",
    attack: 9,
    defense: 9,
    level: 10,
    rarity: "legendary",
    cost: 4,
    effects: [
      { condition: "start_turn", description: "Todos os aliados de Água ganham +1/+1" },
      { condition: "on_attack", description: "Congela o inimigo (pula 1 turno)" }
    ],
    description: "O deus dos mares perdeu sua sanidade."
  },
  {
    name: "Caranguejo de Cristal",
    type: "water",
    attack: 2,
    defense: 5,
    level: 2,
    rarity: "common",
    cost: 1,
    effects: [],
    description: "Defesa impenetrável como o gelo."
  },
  {
    name: "Medusa Aquática",
    type: "water",
    attack: 5,
    defense: 4,
    level: 4,
    rarity: "rare",
    cost: 2,
    effects: [{ condition: "on_defend", description: "Atacante perde 1 ATK permanente" }],
    description: "Seus tentáculos paralisam."
  },
  {
    name: "Espírito do Gêiser",
    type: "water",
    attack: 4,
    defense: 2,
    level: 3,
    rarity: "common",
    cost: 1,
    effects: [{ condition: "on_play", description: "Compre 1 carta" }],
    description: "Da terra, a água jorra com força."
  },
  {
    name: "Kraken Ancião",
    type: "water",
    attack: 8,
    defense: 6,
    level: 7,
    rarity: "epic",
    cost: 3,
    effects: [{ condition: "on_attack", description: "Ataca todos os inimigos" }],
    description: "Seus tentáculos alcançam todos."
  },
  {
    name: "Tsunami Vivo",
    type: "water",
    attack: 10,
    defense: 5,
    level: 9,
    rarity: "legendary",
    cost: 4,
    effects: [{ condition: "on_play", description: "Destrói todas as cartas com DEF ≤3" }],
    description: "Devastação líquida absoluta."
  },

  // PLANT TYPE (10 cards)
  {
    name: "Semente Mágica",
    type: "plant",
    attack: 1,
    defense: 1,
    level: 1,
    rarity: "common",
    cost: 0,
    effects: [{ condition: "start_turn", description: "Ganha +1/+1" }],
    description: "Cresce a cada momento."
  },
  {
    name: "Trepadeira Venenosa",
    type: "plant",
    attack: 3,
    defense: 2,
    level: 2,
    rarity: "common",
    cost: 1,
    effects: [{ condition: "on_attack", description: "Envenena: causa 1 de dano por turno" }],
    description: "Seu toque é letal."
  },
  {
    name: "Ent Guardião",
    type: "plant",
    attack: 4,
    defense: 6,
    level: 5,
    rarity: "rare",
    cost: 2,
    effects: [
      { condition: "vs_type", description: "+3 ATK vs Água", modifier: { attack: 3, targetType: "water" } },
      { condition: "on_defend", description: "Regenera 1 DEF" }
    ],
    description: "Protetor milenar da floresta."
  },
  {
    name: "Flor Carnívora",
    type: "plant",
    attack: 5,
    defense: 3,
    level: 4,
    rarity: "rare",
    cost: 2,
    effects: [{ condition: "on_attack", description: "Se matar, ganha +2/+2 permanente" }],
    description: "Cresce com cada presa."
  },
  {
    name: "Mãe Natureza Corrompida",
    type: "plant",
    attack: 8,
    defense: 8,
    level: 10,
    rarity: "legendary",
    cost: 4,
    effects: [
      { condition: "on_play", description: "Invoca 2 Sementes Mágicas" },
      { condition: "start_turn", description: "Todas as plantas ganham +1/+1" }
    ],
    description: "A natureza decidiu se vingar."
  },
  {
    name: "Esporo Parasita",
    type: "plant",
    attack: 2,
    defense: 1,
    level: 1,
    rarity: "common",
    cost: 0,
    effects: [{ condition: "on_death", description: "Infecta carta inimiga: -1/-1 permanente" }],
    description: "Mesmo na morte, contamina."
  },
  {
    name: "Árvore Anciã",
    type: "plant",
    attack: 3,
    defense: 8,
    level: 6,
    rarity: "epic",
    cost: 2,
    effects: [{ condition: "start_turn", description: "Cura 1 vida e compre 1 carta" }],
    description: "Sabedoria e poder em raízes profundas."
  },
  {
    name: "Cogumelo Explosivo",
    type: "plant",
    attack: 6,
    defense: 1,
    level: 3,
    rarity: "rare",
    cost: 1,
    effects: [{ condition: "on_death", description: "Causa 4 de dano a todos" }],
    description: "Toque nele, se ousar."
  },
  {
    name: "Rosa das Sombras",
    type: "plant",
    attack: 4,
    defense: 4,
    level: 4,
    rarity: "rare",
    cost: 2,
    effects: [{ condition: "on_play", description: "Drena 2 de vida do oponente" }],
    description: "Beleza mortal, perfume letal."
  },
  {
    name: "Hidra Vegetal",
    type: "plant",
    attack: 9,
    defense: 7,
    level: 9,
    rarity: "legendary",
    cost: 3,
    effects: [{ condition: "on_death", description: "Invoca 2 cópias com stats/2" }],
    description: "Corte uma cabeça, nascem duas."
  },

  // SHADOW TYPE (10 cards)
  {
    name: "Sombra Rastejante",
    type: "shadow",
    attack: 2,
    defense: 1,
    level: 1,
    rarity: "common",
    cost: 0,
    effects: [],
    description: "Espreita nas trevas."
  },
  {
    name: "Assassino das Brumas",
    type: "shadow",
    attack: 5,
    defense: 2,
    level: 3,
    rarity: "common",
    cost: 1,
    effects: [{ condition: "on_play", description: "Destrói carta com DEF ≤2" }],
    description: "Silêncio mortal."
  },
  {
    name: "Necromante",
    type: "shadow",
    attack: 4,
    defense: 4,
    level: 5,
    rarity: "rare",
    cost: 2,
    effects: [{ condition: "on_play", description: "Revive uma carta aliada morta" }],
    description: "A morte é apenas o começo."
  },
  {
    name: "Demônio Menor",
    type: "shadow",
    attack: 6,
    defense: 5,
    level: 6,
    rarity: "epic",
    cost: 2,
    effects: [
      { condition: "vs_type", description: "+4 ATK vs Luz", modifier: { attack: 4, targetType: "light" } },
      { condition: "on_attack", description: "Rouba 1 vida" }
    ],
    description: "Alimenta-se da essência vital."
  },
  {
    name: "Lorde das Trevas",
    type: "shadow",
    attack: 10,
    defense: 7,
    level: 10,
    rarity: "legendary",
    cost: 4,
    effects: [
      { condition: "on_play", description: "Todas as cartas de Sombra ganham +2/+2" },
      { condition: "start_turn", description: "Oponente perde 1 vida" }
    ],
    description: "A escuridão feita carne."
  },
  {
    name: "Espectro Faminto",
    type: "shadow",
    attack: 3,
    defense: 3,
    level: 2,
    rarity: "common",
    cost: 1,
    effects: [{ condition: "on_attack", description: "Ganha +1 ATK permanente" }],
    description: "Nunca saciado."
  },
  {
    name: "Vampiro Ancião",
    type: "shadow",
    attack: 7,
    defense: 6,
    level: 7,
    rarity: "epic",
    cost: 3,
    effects: [{ condition: "on_attack", description: "Cura vida igual ao dano causado" }],
    description: "Imortal através do sangue."
  },
  {
    name: "Pesadelo Vivo",
    type: "shadow",
    attack: 5,
    defense: 3,
    level: 4,
    rarity: "rare",
    cost: 2,
    effects: [{ condition: "on_play", description: "Oponente descarta 1 carta" }],
    description: "Materialização dos terrores."
  },
  {
    name: "Ceifador de Almas",
    type: "shadow",
    attack: 8,
    defense: 4,
    level: 8,
    rarity: "epic",
    cost: 3,
    effects: [{ condition: "on_attack", description: "Se matar, ganha ataque extra" }],
    description: "A morte personificada."
  },
  {
    name: "Apocalipse Sombrio",
    type: "shadow",
    attack: 12,
    defense: 6,
    level: 10,
    rarity: "cursed",
    cost: 5,
    effects: [
      { condition: "on_play", description: "Sacrifique todos os aliados. Ganha +2/+2 por cada" },
      { condition: "start_turn", description: "Você perde 2 de vida" }
    ],
    description: "Poder absoluto tem um preço."
  },

  // LIGHT TYPE (5 cards)
  {
    name: "Raio de Esperança",
    type: "light",
    attack: 2,
    defense: 2,
    level: 1,
    rarity: "common",
    cost: 0,
    effects: [{ condition: "on_play", description: "Cura 1 vida" }],
    description: "Luz que nunca se apaga."
  },
  {
    name: "Paladino Sagrado",
    type: "light",
    attack: 5,
    defense: 5,
    level: 5,
    rarity: "rare",
    cost: 2,
    effects: [
      { condition: "vs_type", description: "+5 ATK vs Sombra", modifier: { attack: 5, targetType: "shadow" } },
      { condition: "on_defend", description: "Cura 1 vida" }
    ],
    description: "Protetor dos fracos."
  },
  {
    name: "Anjo da Guarda",
    type: "light",
    attack: 4,
    defense: 6,
    level: 6,
    rarity: "epic",
    cost: 2,
    effects: [{ condition: "on_play", description: "Previne todo o dano neste turno" }],
    description: "Escudo divino."
  },
  {
    name: "Arcanjo Vingador",
    type: "light",
    attack: 8,
    defense: 7,
    level: 9,
    rarity: "legendary",
    cost: 3,
    effects: [
      { condition: "on_attack", description: "Bane criatura de Sombra instantaneamente" },
      { condition: "start_turn", description: "Cura 2 vida" }
    ],
    description: "Justiça implacável."
  },
  {
    name: "Deus Sol Caído",
    type: "light",
    attack: 11,
    defense: 9,
    level: 10,
    rarity: "legendary",
    cost: 4,
    effects: [
      { condition: "on_play", description: "Destrói todas as cartas de Sombra" },
      { condition: "start_turn", description: "Todos os aliados ganham +1/+1 e você ganha 1 vida" }
    ],
    description: "Mesmo caído, sua luz é eterna."
  },

  // ELECTRIC TYPE (5 cards)
  {
    name: "Faísca",
    type: "electric",
    attack: 3,
    defense: 1,
    level: 1,
    rarity: "common",
    cost: 0,
    effects: [{ condition: "on_attack", description: "Causa 1 de dano a cartas adjacentes" }],
    description: "Pequena mas letal."
  },
  {
    name: "Raio Elemental",
    type: "electric",
    attack: 6,
    defense: 3,
    level: 4,
    rarity: "rare",
    cost: 2,
    effects: [
      { condition: "vs_type", description: "+3 ATK vs Água", modifier: { attack: 3, targetType: "water" } },
      { condition: "on_attack", description: "50% de chance de ataque duplo" }
    ],
    description: "Velocidade da luz."
  },
  {
    name: "Dragão Elétrico",
    type: "electric",
    attack: 7,
    defense: 5,
    level: 7,
    rarity: "epic",
    cost: 3,
    effects: [{ condition: "on_play", description: "Causa 2 de dano a todas as cartas inimigas" }],
    description: "Tempestade com asas."
  },
  {
    name: "Thor Mecânico",
    type: "electric",
    attack: 9,
    defense: 6,
    level: 9,
    rarity: "legendary",
    cost: 4,
    effects: [
      { condition: "on_attack", description: "Ataca todas as cartas inimigas" },
      { condition: "start_turn", description: "Todas cartas elétricas ganham +1 ATK" }
    ],
    description: "Deus da tecnologia e trovões."
  },
  {
    name: "Plasma Primordial",
    type: "electric",
    attack: 10,
    defense: 4,
    level: 10,
    rarity: "legendary",
    cost: 4,
    effects: [{ condition: "on_play", description: "Destrói todas as cartas de Água instantaneamente" }],
    description: "Energia pura destrutiva."
  },

  // ICE TYPE (5 cards)
  {
    name: "Cristal Gelado",
    type: "ice",
    attack: 1,
    defense: 3,
    level: 1,
    rarity: "common",
    cost: 0,
    effects: [],
    description: "Frio eterno."
  },
  {
    name: "Lobo do Ártico",
    type: "ice",
    attack: 4,
    defense: 4,
    level: 3,
    rarity: "common",
    cost: 1,
    effects: [{ condition: "on_attack", description: "Congela: inimigo pula próximo turno" }],
    description: "Caçador das terras congeladas."
  },
  {
    name: "Yeti Ancião",
    type: "ice",
    attack: 6,
    defense: 7,
    level: 6,
    rarity: "epic",
    cost: 2,
    effects: [
      { condition: "vs_type", description: "+4 ATK vs Fogo", modifier: { attack: 4, targetType: "fire" } },
      { condition: "on_defend", description: "Congela o atacante" }
    ],
    description: "Lenda das montanhas."
  },
  {
    name: "Dragão de Gelo",
    type: "ice",
    attack: 8,
    defense: 6,
    level: 8,
    rarity: "epic",
    cost: 3,
    effects: [{ condition: "on_play", description: "Congela todas as cartas inimigas por 1 turno" }],
    description: "Sopro que congela a alma."
  },
  {
    name: "Era Glacial",
    type: "ice",
    attack: 10,
    defense: 10,
    level: 10,
    rarity: "legendary",
    cost: 5,
    effects: [
      { condition: "on_play", description: "Todas as cartas inimigas perdem -2/-2" },
      { condition: "start_turn", description: "Congela uma carta inimiga aleatória" }
    ],
    description: "O fim de tudo em gelo eterno."
  },

  // POISON TYPE (5 cards)
  {
    name: "Fungo Tóxico",
    type: "poison",
    attack: 1,
    defense: 2,
    level: 1,
    rarity: "common",
    cost: 0,
    effects: [{ condition: "on_attack", description: "Envenena: 1 dano/turno" }],
    description: "Esporos letais."
  },
  {
    name: "Serpente Venenosa",
    type: "poison",
    attack: 4,
    defense: 2,
    level: 3,
    rarity: "common",
    cost: 1,
    effects: [{ condition: "on_attack", description: "Envenena: 2 dano/turno" }],
    description: "Presas mortais."
  },
  {
    name: "Aranha Colossal",
    type: "poison",
    attack: 5,
    defense: 5,
    level: 5,
    rarity: "rare",
    cost: 2,
    effects: [{ condition: "on_attack", description: "Paralisa e envenena" }],
    description: "Teia de morte."
  },
  {
    name: "Hidra Venenosa",
    type: "poison",
    attack: 7,
    defense: 6,
    level: 7,
    rarity: "epic",
    cost: 3,
    effects: [{ condition: "on_attack", description: "Envenena todos os inimigos" }],
    description: "Cada cabeça cuspedeath veneno."
  },
  {
    name: "Rei das Toxinas",
    type: "poison",
    attack: 9,
    defense: 8,
    level: 10,
    rarity: "legendary",
    cost: 4,
    effects: [
      { condition: "on_play", description: "Duplica todo o veneno no campo" },
      { condition: "start_turn", description: "Todos os inimigos são envenenados: 1 dano/turno" }
    ],
    description: "Veneno em forma divina."
  }
];

// Helper to get cards by type
export const getCardsByType = (type: CardType) => 
  CREATURE_CARDS.filter(card => card.type === type);

// Helper to get cards by rarity
export const getCardsByRarity = (rarity: string) => 
  CREATURE_CARDS.filter(card => card.rarity === rarity);

// Helper to get cards by level
export const getCardsByLevel = (level: number) => 
  CREATURE_CARDS.filter(card => card.level === level);

// Helper to get cards by level range
export const getCardsByLevelRange = (minLevel: number, maxLevel: number) => 
  CREATURE_CARDS.filter(card => card.level >= minLevel && card.level <= maxLevel);

// Helper to get random cards
export const getRandomCards = (count: number) => {
  const shuffled = [...CREATURE_CARDS].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
};

// Helper to get random cards by level
export const getRandomCardsByLevel = (count: number, level: number) => {
  const levelCards = getCardsByLevel(level);
  const shuffled = [...levelCards].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
};

// Helper to get random cards by level range
export const getRandomCardsByLevelRange = (count: number, minLevel: number, maxLevel: number) => {
  const rangeCards = getCardsByLevelRange(minLevel, maxLevel);
  const shuffled = [...rangeCards].sort(() => Math.random() - 0.5);
  return shuffled.slice(0, count);
};
