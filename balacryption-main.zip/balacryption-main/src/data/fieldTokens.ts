import { FieldToken, CardType } from "@/types/card";

export interface TokenEffect {
  id: string;
  name: string;
  description: string;
  effect: "atk_down" | "def_down" | "cost_up" | "hp_drain" | "no_heal" | "double_damage";
  value: number;
  level: 1 | 2 | 3;
}

// Definição clara de todos os efeitos de tokens por nível
export const TOKEN_EFFECTS: TokenEffect[] = [
  // Nível 1 - Efeitos fracos
  {
    id: "atk_down_1",
    name: "Fraqueza Elemental I",
    description: "Criaturas deste elemento perdem -1 ATK",
    effect: "atk_down",
    value: 1,
    level: 1
  },
  {
    id: "def_down_1",
    name: "Armadura Quebrada I",
    description: "Criaturas deste elemento perdem -1 DEF",
    effect: "def_down",
    value: 1,
    level: 1
  },
  
  // Nível 2 - Efeitos médios
  {
    id: "atk_down_2",
    name: "Fraqueza Elemental II",
    description: "Criaturas deste elemento perdem -2 ATK",
    effect: "atk_down",
    value: 2,
    level: 2
  },
  {
    id: "def_down_2",
    name: "Armadura Quebrada II",
    description: "Criaturas deste elemento perdem -2 DEF",
    effect: "def_down",
    value: 2,
    level: 2
  },
  {
    id: "cost_up_2",
    name: "Ritual Complexo II",
    description: "Invocar criaturas deste elemento custa +1 sacrifício",
    effect: "cost_up",
    value: 1,
    level: 2
  },
  {
    id: "hp_drain_2",
    name: "Drenagem de Vida II",
    description: "Perde 1 HP no início de cada turno se tiver criatura deste elemento",
    effect: "hp_drain",
    value: 1,
    level: 2
  },
  
  // Nível 3 - Efeitos fortes
  {
    id: "atk_down_3",
    name: "Fraqueza Elemental III",
    description: "Criaturas deste elemento perdem -3 ATK",
    effect: "atk_down",
    value: 3,
    level: 3
  },
  {
    id: "def_down_3",
    name: "Armadura Quebrada III",
    description: "Criaturas deste elemento perdem -3 DEF",
    effect: "def_down",
    value: 3,
    level: 3
  },
  {
    id: "cost_up_3",
    name: "Ritual Complexo III",
    description: "Invocar criaturas deste elemento custa +2 sacrifícios",
    effect: "cost_up",
    value: 2,
    level: 3
  },
  {
    id: "hp_drain_3",
    name: "Drenagem de Vida III",
    description: "Perde 2 HP no início de cada turno se tiver criatura deste elemento",
    effect: "hp_drain",
    value: 2,
    level: 3
  },
  {
    id: "no_heal_3",
    name: "Veneno Persistente III",
    description: "Não pode curar vida enquanto tiver criatura deste elemento no campo",
    effect: "no_heal",
    value: 0,
    level: 3
  },
  {
    id: "double_damage_3",
    name: "Maldição Frágil III",
    description: "Criaturas deste elemento recebem dobro de dano",
    effect: "double_damage",
    value: 2,
    level: 3
  }
];

// Nomes temáticos dos cristais por elemento
const CRYSTAL_NAMES: Record<CardType, string> = {
  fire: "Cristal de Chamas Corrompidas",
  water: "Cristal das Águas Sombrias",
  plant: "Cristal da Natureza Morta",
  shadow: "Cristal das Trevas Eternas",
  light: "Cristal da Luz Apagada",
  electric: "Cristal do Trovão Caótico",
  ice: "Cristal da Nevasca Eterna",
  poison: "Cristal do Veneno Ancestral",
  metal: "Cristal do Metal Enferrujado",
  spirit: "Cristal dos Espíritos Perdidos"
};

// Gera um token de campo aleatório com nível
export const generateFieldToken = (level?: 1 | 2 | 3): FieldToken => {
  const elements: CardType[] = ["fire", "water", "plant", "shadow", "light", "electric", "ice", "poison"];
  const targetElement = elements[Math.floor(Math.random() * elements.length)];
  
  // Se não especificado, escolhe um nível aleatório
  const tokenLevel = level || ([1, 2, 3][Math.floor(Math.random() * 3)] as 1 | 2 | 3);
  
  // Filtra efeitos pelo nível
  const effectsForLevel = TOKEN_EFFECTS.filter(e => e.level === tokenLevel);
  const selectedEffect = effectsForLevel[Math.floor(Math.random() * effectsForLevel.length)];
  
  const token: FieldToken = {
    id: `token-${Date.now()}`,
    name: `${CRYSTAL_NAMES[targetElement]} Nv.${tokenLevel}`,
    type: "nerf",
    targetElement,
    effect: selectedEffect.effect,
    description: `${targetElement.toUpperCase()}: ${selectedEffect.description}`
  };
  
  return token;
};

// Aplica o efeito de um token em uma carta
export const applyTokenEffect = (
  card: any,
  token: FieldToken | null,
  context: "cost" | "stats" | "damage" | "heal"
): number => {
  if (!token || card.type !== token.targetElement) return 0;
  
  const effect = TOKEN_EFFECTS.find(e => e.effect === token.effect);
  if (!effect) return 0;
  
  switch (context) {
    case "cost":
      return token.effect === "cost_up" ? effect.value : 0;
    case "stats":
      if (token.effect === "atk_down" || token.effect === "def_down") {
        return -effect.value;
      }
      return 0;
    case "damage":
      return token.effect === "double_damage" ? effect.value : 1;
    case "heal":
      return token.effect === "no_heal" ? 0 : 1;
    default:
      return 0;
  }
};

// Verifica se deve drenar HP baseado no token ativo
export const shouldDrainHP = (board: any[], token: FieldToken | null): boolean => {
  if (!token || token.effect !== "hp_drain") return false;
  return board.some(card => card && card.type === token.targetElement);
};

// Verifica se pode curar baseado no token ativo
export const canHeal = (board: any[], token: FieldToken | null): boolean => {
  if (!token || token.effect !== "no_heal") return true;
  return !board.some(card => card && card.type === token.targetElement);
};
