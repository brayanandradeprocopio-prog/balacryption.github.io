import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { GameBoard } from "@/components/GameBoard";
import { Tutorial } from "@/components/Tutorial";
import { HelpDialog } from "@/components/HelpDialog";
import { CardRewardSelector } from "@/components/CardRewardSelector";
import { Card, FieldToken } from "@/types/card";
import { getRandomCardsByLevel, getRandomCardsByLevelRange } from "@/data/creatures";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { BattleSystem } from "@/systems/battleSystem";
import { AISystem } from "@/systems/aiSystem";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

type WaveEvent = {
  type: "heal" | "damage" | "draw" | "enemy_buff" | "player_buff" | "curse";
  title: string;
  description: string;
  action: () => void;
};

const Game = () => {
  const [gameStarted, setGameStarted] = useState(false);
  const [showTutorial, setShowTutorial] = useState(false);
  const [hand, setHand] = useState<Card[]>([]);
  const [board, setBoard] = useState<Card[]>([]);
  const [enemyBoard, setEnemyBoard] = useState<Card[]>([]);
  const [playerHP, setPlayerHP] = useState(20);
  const [enemyHP, setEnemyHP] = useState(20);
  const [currentTurn, setCurrentTurn] = useState<"player" | "enemy">("player");
  const [roundNumber, setRoundNumber] = useState(1);
  const [waveNumber, setWaveNumber] = useState(1);
  const [graveyard, setGraveyard] = useState<Card[]>([]);
  const [enemyGraveyard, setEnemyGraveyard] = useState<Card[]>([]);
  const [gameMode, setGameMode] = useState<"normal" | "corruption">("normal");
  const [fieldToken, setFieldToken] = useState<FieldToken | null>(null);
  const [sacrificePot, setSacrificePot] = useState(0); // Pote de pontos de sacrifício (max 5)
  const [sacrificeMode, setSacrificeMode] = useState<{
    active: boolean;
    cardToPlay: Card | null;
    selectedSacrifices: string[];
    required: number;
    type: "invoke" | "store"; // invoke = invocar carta, store = guardar pontos
  }>({
    active: false,
    cardToPlay: null,
    selectedSacrifices: [],
    required: 0,
    type: "invoke"
  });
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  const [showRewardSelector, setShowRewardSelector] = useState(false);
  const [rewardCards, setRewardCards] = useState<Card[]>([]);
  const { toast } = useToast();
  const navigate = useNavigate();

  useEffect(() => {
    // Verifica se tem deck customizado do modo construtor ou modo corruption
    const urlParams = new URLSearchParams(window.location.search);
    const mode = urlParams.get("mode");
    
    if (mode === "corruption" || mode === "corruption-custom") {
      setGameMode("corruption");
    } 
    
    if (mode === "custom" || mode === "corruption-custom") {
      const savedDeck = localStorage.getItem("customDeck");
      if (savedDeck) {
        const deck = JSON.parse(savedDeck);
        const hasSeenTutorial = localStorage.getItem("tutorialCompleted");
        if (!hasSeenTutorial) {
          setShowTutorial(true);
        } else {
          initializeGame(deck);
        }
        localStorage.removeItem("customDeck");
      }
    }
  }, []);


  const generateFieldToken = () => {
    const elements: Card["type"][] = ["fire", "water", "plant", "shadow", "light", "electric", "ice", "poison"];
    const targetElement = elements[Math.floor(Math.random() * elements.length)];
    
    const tokenEffects = [
      { effect: "atk_down", name: "Fraqueza Elemental", description: "Criaturas perdem -2 ATK" },
      { effect: "def_down", name: "Armadura Quebrada", description: "Criaturas perdem -2 DEF" },
      { effect: "cost_up", name: "Ritual Complexo", description: "Custo de invocação +1 sacrifício" },
      { effect: "hp_drain", name: "Drenagem de Vida", description: "Perde 1 HP no início do turno" },
      { effect: "no_heal", name: "Veneno Persistente", description: "Não pode curar vida" },
      { effect: "double_damage", name: "Maldição Frágil", description: "Recebe dobro de dano" }
    ];
    
    const selectedEffect = tokenEffects[Math.floor(Math.random() * tokenEffects.length)];
    
    const crystalNames: Record<string, string> = {
      fire: "Cristal de Chamas Corrompidas",
      water: "Cristal das Águas Sombrias", 
      plant: "Cristal da Natureza Morta",
      shadow: "Cristal das Trevas Eternas",
      light: "Cristal da Luz Apagada",
      electric: "Cristal do Trovão Caótico",
      ice: "Cristal da Nevasca Eterna",
      poison: "Cristal do Veneno Ancestral"
    };
    
    const token: FieldToken = {
      id: `token-${Date.now()}`,
      name: crystalNames[targetElement] || "Cristal Corrompido",
      type: "nerf",
      targetElement,
      effect: selectedEffect.effect,
      description: `${targetElement.toUpperCase()}: ${selectedEffect.description}`
    };
    
    setFieldToken(token);
    
    toast({
      title: `💎 ${selectedEffect.name}`,
      description: `${token.name} - ${token.description}`,
      duration: 5000
    });
  };

  const triggerRandomEvent = () => {
    // Eventos só acontecem no modo Corruption
    if (gameMode !== "corruption") return;
    
    // 60% de chance de evento acontecer por turno (aumentado!)
    if (Math.random() > 0.6) return;

    const events: WaveEvent[] = [
      {
        type: "heal",
        title: "🌟 Bênção Sombria",
        description: "Uma energia estranha restaura 3 HP!",
        action: () => {
          setPlayerHP(prev => Math.min(20, prev + 3));
        }
      },
      {
        type: "damage",
        title: "⚡ Relâmpago Caótico",
        description: "Um raio atinge você! -2 HP",
        action: () => {
          setPlayerHP(prev => Math.max(0, prev - 2));
        }
      },
      {
        type: "draw",
        title: "🎴 Vento Místico",
        description: "Cartas flutuam do cemitério!",
        action: () => {
          if (graveyard.length > 0) {
            const card = graveyard[graveyard.length - 1];
            setGraveyard(prev => prev.slice(0, -1));
            setHand(prev => [...prev, card]);
          }
        }
      },
      {
        type: "enemy_buff",
        title: "💀 Ritual Obscuro",
        description: "O inimigo invoca +1 criatura!",
        action: () => {
          if (enemyBoard.length < 4) {
            const enemyCard = getRandomCardsByLevel(1, Math.min(waveNumber, 5))[0];
            if (enemyCard) {
              setEnemyBoard(prev => [...prev, { ...enemyCard, id: `enemy-${Date.now()}` }]);
            }
          }
        }
      },
      {
        type: "player_buff",
        title: "✨ Sorte do Abismo",
        description: "Suas criaturas ganham +1/+1!",
        action: () => {
          setBoard(prev => prev.map(card => ({
            ...card,
            attack: card.attack + 1,
            defense: card.defense + 1
          })));
        }
      },
      {
        type: "curse",
        title: "🌑 Maldição Ancestral",
        description: "Todas as criaturas perdem 1 de defesa!",
        action: () => {
          setBoard(prev => prev.map(card => ({
            ...card,
            defense: Math.max(1, card.defense - 1)
          })));
          setEnemyBoard(prev => prev.map(card => ({
            ...card,
            defense: Math.max(1, card.defense - 1)
          })));
        }
      },
      {
        type: "damage",
        title: "🔥 Chamas da Corrupção",
        description: "Todas as criaturas de fogo recebem dano!",
        action: () => {
          setBoard(prev => prev.map(card => 
            card.type === "fire" ? { ...card, defense: Math.max(0, card.defense - 2) } : card
          ));
          setEnemyBoard(prev => prev.map(card => 
            card.type === "fire" ? { ...card, defense: Math.max(0, card.defense - 2) } : card
          ));
        }
      },
      {
        type: "heal",
        title: "💧 Chuva Purificadora",
        description: "Criaturas de água ganham +2 de defesa!",
        action: () => {
          setBoard(prev => prev.map(card => 
            card.type === "water" ? { ...card, defense: card.defense + 2 } : card
          ));
        }
      },
      {
        type: "enemy_buff",
        title: "⚡ Tempestade Elétrica",
        description: "Criaturas elétricas ganham +1 de ataque!",
        action: () => {
          setEnemyBoard(prev => prev.map(card => 
            card.type === "electric" ? { ...card, attack: card.attack + 1 } : card
          ));
        }
      },
      {
        type: "curse",
        title: "🌿 Espinhos Venenosos",
        description: "Criaturas de planta causam 1 de dano ao serem atacadas!",
        action: () => {
          const plantCards = board.filter(card => card.type === "plant");
          if (plantCards.length > 0) {
            setEnemyHP(prev => Math.max(0, prev - plantCards.length));
          }
        }
      },
      {
        type: "draw",
        title: "👻 Portal Espectral",
        description: "Uma criatura aleatória volta do cemitério!",
        action: () => {
          if (graveyard.length > 0) {
            const randomIndex = Math.floor(Math.random() * graveyard.length);
            const resurrectedCard = graveyard[randomIndex];
            setGraveyard(prev => prev.filter((_, i) => i !== randomIndex));
            setHand(prev => [...prev, { ...resurrectedCard, id: `resurrected-${Date.now()}` }]);
          }
        }
      },
      {
        type: "curse",
        title: "❄️ Nevasca Congelante",
        description: "Todas as criaturas congelam (-1 ATK)!",
        action: () => {
          setBoard(prev => prev.map(card => ({
            ...card,
            attack: Math.max(0, card.attack - 1)
          })));
          setEnemyBoard(prev => prev.map(card => ({
            ...card,
            attack: Math.max(0, card.attack - 1)
          })));
        }
      },
      {
        type: "player_buff",
        title: "☀️ Raio de Luz Divina",
        description: "Criaturas de luz restauram 2 HP!",
        action: () => {
          const lightCards = board.filter(card => card.type === "light");
          if (lightCards.length > 0) {
            setPlayerHP(prev => Math.min(20, prev + (lightCards.length * 2)));
          }
        }
      },
      {
        type: "enemy_buff",
        title: "🌑 Eclipse Sombrio",
        description: "Criaturas de sombra do inimigo ganham +2/+1!",
        action: () => {
          setEnemyBoard(prev => prev.map(card => 
            card.type === "shadow" ? { 
              ...card, 
              attack: card.attack + 2, 
              defense: card.defense + 1 
            } : card
          ));
        }
      }
    ];

    const randomEvent = events[Math.floor(Math.random() * events.length)];
    
    toast({ 
      title: randomEvent.title, 
      description: randomEvent.description,
      duration: 3000
    });
    
    setTimeout(() => {
      randomEvent.action();
    }, 500);
  };

  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.key === "Escape" && showTutorial) {
        completeTutorial();
      }
    };
    window.addEventListener("keydown", handleKeyPress);
    return () => window.removeEventListener("keydown", handleKeyPress);
  }, [showTutorial]);

  const startGame = () => {
    const hasSeenTutorial = localStorage.getItem("tutorialCompleted");
    if (!hasSeenTutorial) {
      setShowTutorial(true);
    } else {
      initializeGame();
    }
  };

  const completeTutorial = () => {
    localStorage.setItem("tutorialCompleted", "true");
    setShowTutorial(false);
    
    // Verifica se tem deck customizado
    const urlParams = new URLSearchParams(window.location.search);
    const mode = urlParams.get("mode");
    if (mode === "custom" || mode === "corruption-custom") {
      const savedDeck = localStorage.getItem("customDeck");
      if (savedDeck) {
        const deck = JSON.parse(savedDeck);
        initializeGame(deck);
        localStorage.removeItem("customDeck");
        return;
      }
    }
    
    initializeGame();
  };

  const initializeGame = async (deck?: Card[]) => {
    setGameStarted(true);
    setPlayerHP(20);
    setEnemyHP(20);
    setCurrentTurn("player");
    setRoundNumber(1);
    setWaveNumber(1);
    setGraveyard([]);
    setEnemyGraveyard([]);
    setSacrificePot(0);
    setSacrificeMode({
      active: false,
      cardToPlay: null,
      selectedSacrifices: [],
      required: 0,
      type: "invoke"
    });
    
    // Gera ficha de campo inicial apenas no modo BALA (normal)
    if (gameMode === "normal") {
      generateFieldToken();
    }
    
    
    // Se tiver deck customizado, usa ele, senão gera automaticamente
    let initialCards: Card[];
    if (deck && deck.length > 0) {
      initialCards = deck.map((card, index) => ({
        ...card,
        id: `custom-${Date.now()}-${index}`
      }));
    } else {
      // 6 cartas de nível 1 + 4 cartas aleatórias de nível 2-4
      const level1Cards = getRandomCardsByLevel(6, 1).map((card, index) => ({
        ...card,
        id: `card-${Date.now()}-l1-${index}`
      }));
      
      const randomCards = getRandomCardsByLevelRange(4, 2, 4).map((card, index) => ({
        ...card,
        id: `card-${Date.now()}-rand-${index}`
      }));
      
      initialCards = [...level1Cards, ...randomCards];
    }
    
    setHand(initialCards);
    setBoard([]);
    setEnemyBoard([]);

    toast({
      title: "Batalha Iniciada",
      description: "Seu turno! Posicione suas cartas.",
    });
  };

  const handlePlayCard = (cardId: string) => {
    if (currentTurn !== "player") {
      toast({ title: "Não é seu turno!", variant: "destructive" });
      return;
    }

    if (board.length >= 4) {
      toast({ title: "Campo Cheio", description: "Máximo de 4 cartas!", variant: "destructive" });
      return;
    }

    const cardToPlay = hand.find(c => c.id === cardId);
    if (!cardToPlay) return;

    // Verifica se a carta requer pontos de sacrifício
    if (cardToPlay.cost > 0) {
      // Verifica se tem pontos suficientes no pote
      if (sacrificePot < cardToPlay.cost) {
        toast({ 
          title: "Pontos Insuficientes", 
          description: `Esta carta requer ${cardToPlay.cost} ponto(s) de sacrifício. Você tem ${sacrificePot}/5.`,
          variant: "destructive" 
        });
        return;
      }

      // Consome pontos do pote
      setSacrificePot(prev => prev - cardToPlay.cost);
      
      // Joga a carta com animação
      const { effects, modifiedCard } = BattleSystem.onCardPlayed(cardToPlay);
      setHand(prev => prev.filter(c => c.id !== cardId));
      
      // Adiciona animação de invocação
      setTimeout(() => {
        setBoard(prev => [...prev, modifiedCard]);
        
        if (effects.length > 0) {
          toast({ 
            title: "✨ Efeito Ativado!", 
            description: effects.join(", "),
            duration: 3000 
          });
        }
        
        toast({
          title: "⚡ Invocação Completa",
          description: `${cardToPlay.name} invocada! Pontos restantes: ${sacrificePot - cardToPlay.cost}/5`
        });
      }, 150);
      return;
    }

    // Carta de nível 1 - joga direto com animação
    const { effects, modifiedCard } = BattleSystem.onCardPlayed(cardToPlay);
    setHand(prev => prev.filter(c => c.id !== cardId));
    
    setTimeout(() => {
      setBoard(prev => [...prev, modifiedCard]);
      
      if (effects.length > 0) {
        toast({ 
          title: "✨ Efeito Ativado!", 
          description: effects.join(", "),
          duration: 3000 
        });
      }
    }, 150);
  };

  const startSacrificeForPoints = () => {
    if (sacrificePot >= 5) {
      toast({
        title: "Pote Cheio",
        description: "O pote já está no máximo (5/5)!",
        variant: "destructive"
      });
      return;
    }

    setSacrificeMode({
      active: true,
      cardToPlay: null,
      selectedSacrifices: [],
      required: 0,
      type: "store"
    });

    toast({
      title: "Modo Sacrifício Ativado",
      description: "Clique em cartas da mão ou campo para sacrificar e ganhar pontos!"
    });
  };

  const handleSacrificeCard = (cardId: string, fromHand: boolean = false) => {
    if (!sacrificeMode.active) return;

    if (sacrificeMode.type === "store") {
      // Sacrificar para ganhar pontos
      if (sacrificePot >= 5) {
        toast({
          title: "Pote Cheio",
          description: "Máximo de 5 pontos atingido!",
          variant: "destructive"
        });
        return;
      }

      let sacrificedCard: Card | undefined;
      
      if (fromHand) {
        sacrificedCard = hand.find(c => c.id === cardId);
        setHand(prev => prev.filter(c => c.id !== cardId));
      } else {
        sacrificedCard = board.find(c => c.id === cardId);
        setBoard(prev => prev.filter(c => c.id !== cardId));
      }

      if (sacrificedCard) {
        setGraveyard(prev => [...prev, sacrificedCard]);
        setSacrificePot(prev => Math.min(5, prev + 1));
        
        toast({
          title: "Sacrifício Realizado",
          description: `${sacrificedCard.name} sacrificada! Pontos: ${Math.min(5, sacrificePot + 1)}/5`
        });

        // Desativa modo após sacrifício
        setSacrificeMode({
          active: false,
          cardToPlay: null,
          selectedSacrifices: [],
          required: 0,
          type: "invoke"
        });
      }
    }
  };

  const executeSacrifice = (sacrificeIds: string[], cardToPlay: Card) => {
    // Marca cartas para animação
    setBoard(prev => prev.map(card => 
      sacrificeIds.includes(card.id) ? { ...card, isSacrificing: true } : card
    ));

    // Aguarda animação e remove do campo
    setTimeout(() => {
      const sacrificedCards = board.filter(card => sacrificeIds.includes(card.id));
      
      // Ativa efeitos de sacrifício
      sacrificedCards.forEach(card => {
        const sacrificeEffects = card.effects.filter(e => e.condition === "on_sacrifice");
        if (sacrificeEffects.length > 0) {
          toast({ 
            title: "Efeito de Sacrifício!", 
            description: sacrificeEffects.map(e => e.description).join(", ")
          });
        }
      });

      // Move para cemitério
      setGraveyard(prev => [...prev, ...sacrificedCards]);
      
      // Remove do campo
      setBoard(prev => prev.filter(card => !sacrificeIds.includes(card.id)));
      
      // Remove da mão
      setHand(prev => prev.filter(c => c.id !== cardToPlay.id));
      
      // Invoca a carta
      const { effects, modifiedCard } = BattleSystem.onCardPlayed(cardToPlay);
      setBoard(prev => [...prev, modifiedCard]);

      // Reset modo sacrifício
      setSacrificeMode({
        active: false,
        cardToPlay: null,
        selectedSacrifices: [],
        required: 0,
        type: "invoke"
      });

      toast({
        title: "Sacrifício Realizado!",
        description: `${cardToPlay.name} foi invocada com o sacrifício de ${sacrificedCards.length} carta(s)!`,
      });

      if (effects.length > 0) {
        setTimeout(() => {
          toast({ title: "Efeito Ativado!", description: effects.join(", ") });
        }, 500);
      }
    }, 500);
  };

  const endTurn = async () => {
    if (currentTurn !== "player") return;

    const { playerDamage, enemyDamage, destroyedDefenders, destroyedAttackers } = 
      BattleSystem.resolveCombat(board, enemyBoard);
    
    // Remove cartas destruídas e adiciona ao cemitério
    if (destroyedDefenders.length > 0) {
      const destroyed = enemyBoard.filter((_, index) => destroyedDefenders.includes(index));
      setEnemyGraveyard(prev => [...prev, ...destroyed]);
      setEnemyBoard(prev => prev.filter((_, index) => !destroyedDefenders.includes(index)));
      toast({ 
        title: "Cartas Destruídas!", 
        description: `Você destruiu ${destroyedDefenders.length} carta(s) inimiga(s)!` 
      });
    }
    
    if (destroyedAttackers.length > 0) {
      const destroyed = board.filter((_, index) => destroyedAttackers.includes(index));
      setGraveyard(prev => [...prev, ...destroyed]);
      setBoard(prev => prev.filter((_, index) => !destroyedAttackers.includes(index)));
    }
    
    const newEnemyHP = Math.max(0, enemyHP - playerDamage);
    const newPlayerHP = Math.max(0, playerHP - enemyDamage);
    
    setEnemyHP(newEnemyHP);
    setPlayerHP(newPlayerHP);

    if (playerDamage > 0) {
      toast({ title: "Ataque Direto!", description: `Você causou ${playerDamage} de dano direto!` });
    }

    if (newEnemyHP <= 0) {
      await handleWaveComplete();
      return;
    }

    if (newPlayerHP <= 0) {
      await handleDefeat();
      return;
    }

    setCurrentTurn("enemy");
    setTimeout(() => executeAITurn(), 1500);
  };

  const executeAITurn = () => {
    const aiCards = AISystem.generateAIHand(roundNumber, waveNumber);
    const aiBoard = AISystem.playCards(aiCards, enemyBoard, board, waveNumber);
    setEnemyBoard(aiBoard);

    const aiThreat = AISystem.calculateThreatLevel(aiBoard);
    const threatLevel = aiThreat > 20 ? "ALTA" : aiThreat > 10 ? "MÉDIA" : "BAIXA";

    toast({ 
      title: "Turno do Inimigo", 
      description: `O inimigo posicionou suas cartas... Ameaça: ${threatLevel}` 
    });

    setTimeout(() => {
      const { playerDamage, enemyDamage, destroyedDefenders, destroyedAttackers } = 
        BattleSystem.resolveCombat(aiBoard, board);
      
      // Remove cartas destruídas e adiciona ao cemitério
      if (destroyedAttackers.length > 0) {
        const destroyed = aiBoard.filter((_, index) => destroyedAttackers.includes(index));
        setEnemyGraveyard(prev => [...prev, ...destroyed]);
        setEnemyBoard(prev => prev.filter((_, index) => !destroyedAttackers.includes(index)));
      }
      
      if (destroyedDefenders.length > 0) {
        const destroyed = board.filter((_, index) => destroyedDefenders.includes(index));
        setGraveyard(prev => [...prev, ...destroyed]);
        setBoard(prev => prev.filter((_, index) => !destroyedDefenders.includes(index)));
        toast({ 
          title: "Suas Cartas Foram Destruídas!", 
          description: `Você perdeu ${destroyedDefenders.length} carta(s)!`,
          variant: "destructive" 
        });
      }
      
      const newPlayerHP = Math.max(0, playerHP - playerDamage);
      setPlayerHP(newPlayerHP);

      if (playerDamage > 0) {
        toast({ 
          title: "Você foi atacado!", 
          description: `Recebeu ${playerDamage} de dano direto!`, 
          variant: "destructive" 
        });
      }

      if (newPlayerHP <= 0) {
        handleDefeat();
        return;
      }

      setCurrentTurn("player");
      setRoundNumber(prev => prev + 1);

      // Se a mão tiver menos de 3 cartas, dá 5 cartas de nível 1 a 5
      setTimeout(() => {
        if (hand.length < 3) {
          const newCards = getRandomCardsByLevelRange(5, 1, 5).map((card, index) => ({
            ...card,
            id: `draw-${Date.now()}-${index}`
          }));
          
          setHand(prev => [...prev, ...newCards]);
          
          toast({
            title: "🎴 Novas Cartas Recebidas!",
            description: `Você recebeu 5 novas cartas! Total: ${hand.length + 5}`,
            duration: 3000
          });
        } else {
          // Pega carta do cemitério se mão tiver menos de 5 cartas
          if (hand.length < 5 && graveyard.length > 0) {
            const cardFromGraveyard = graveyard[graveyard.length - 1];
            setGraveyard(prev => prev.slice(0, -1));
            setHand(prev => [...prev, cardFromGraveyard]);
            toast({ 
              title: "Carta Recuperada", 
              description: `Você pegou ${cardFromGraveyard.name} do cemitério!`,
              duration: 2000
            });
          }
        }

        // Chance de evento aleatório acontecer (apenas no modo Corruption)
        if (gameMode === "corruption") {
          triggerRandomEvent();
        }
      }, 500);

      toast({ title: "Seu Turno", description: `Turno ${roundNumber + 1} - Onda ${waveNumber}` });
    }, 2000);
  };

  const handleWaveComplete = async () => {
    const waveReward = 100 * waveNumber;
    
    // Troca a ficha de campo a cada 5 ondas no modo BALA (normal)
    if (gameMode === "normal" && waveNumber % 5 === 0) {
      generateFieldToken();
      toast({
        title: "🔮 Nova Ficha de Campo!",
        description: "O campo foi alterado!",
        duration: 3000
      });
    }
    
    
    toast({ 
      title: `ONDA ${waveNumber} COMPLETA!`, 
      description: `+${waveReward} XP! Escolha sua recompensa...`,
      duration: 3000
    });
    
    // Gera 5 cartas para escolha, respeitando limite de nível baseado na onda
    const maxLevel = waveNumber <= 5 ? 5 : 10;
    const rewards = getRandomCardsByLevelRange(5, 1, maxLevel).map((card, index) => ({
      ...card,
      id: `reward-${Date.now()}-${index}`
    }));
    
    setRewardCards(rewards);
    setShowRewardSelector(true);
  };

  const handleRewardSelection = (selectedCards: Card[]) => {
    setHand(prev => [...prev, ...selectedCards]);
    setShowRewardSelector(false);
    
    toast({ 
      title: "Recompensas Recebidas!", 
      description: `Você ganhou: ${selectedCards.map(c => c.name).join(", ")}`
    });
    
    // Prepara para próxima onda
    setTimeout(() => {
      const nextWave = waveNumber + 1;
      setWaveNumber(nextWave);
      setEnemyHP(20 + (nextWave - 1) * 5);
      setRoundNumber(1);
      
      // Devolve cartas do campo para a mão
      setHand(prev => [...prev, ...board]);
      setBoard([]);
      setEnemyBoard([]);
      
      toast({ 
        title: "Cartas Retornadas", 
        description: `Suas cartas retornaram para a mão!`,
        duration: 2000
      });
      
      // Jogador recupera HP entre ondas
      const healAmount = Math.min(5, 20 - playerHP);
      if (healAmount > 0) {
        setPlayerHP(prev => Math.min(20, prev + healAmount));
        toast({ title: "Recuperação", description: `Você recuperou ${healAmount} HP!` });
      }
      
      toast({ 
        title: `ONDA ${nextWave} INICIADA!`, 
        description: `Os inimigos estão mais fortes! Boss HP: ${20 + (nextWave - 1) * 5}`,
        duration: 4000
      });
      
      setCurrentTurn("player");
    }, 1000);
  };

  const handleDefeat = async () => {
    toast({ title: "DERROTA", description: `Você sobreviveu até a Onda ${waveNumber}!`, variant: "destructive" });
    setTimeout(() => setGameStarted(false), 3000);
  };

  if (showTutorial) {
    return <Tutorial onComplete={completeTutorial} gameMode={gameMode} />;
  }

  if (!gameStarted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-background to-background/80 p-4 relative">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate("/")}
          className="absolute top-4 left-4 neon-cyan"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="max-w-2xl w-full space-y-8 text-center animate-fade-in">
          <div className="space-y-4">
            <h1 className="text-6xl font-bold neon-cyan glitch-text">O Dealer</h1>
            <p className="text-xl text-muted-foreground">
              Um jogo onde suas escolhas têm consequências...
            </p>
          </div>
          
          <Button size="lg" onClick={startGame} className="text-lg px-8 py-6 bg-primary hover:bg-primary/80">
            Iniciar Batalha
          </Button>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-12 text-sm">
            <div className="card-dark p-4">
              <h3 className="font-bold mb-2 neon-cyan">Campo 4x2</h3>
              <p className="text-muted-foreground">Posicione até 4 cartas no seu campo de batalha</p>
            </div>
            <div className="card-dark p-4">
              <h3 className="font-bold mb-2 neon-cyan">Sacrifícios</h3>
              <p className="text-muted-foreground">Sacrifique cartas para invocar criaturas poderosas</p>
            </div>
            <div className="card-dark p-4">
              <h3 className="font-bold mb-2 neon-cyan">20 HP</h3>
              <p className="text-muted-foreground">Reduza a vida do oponente a zero para vencer</p>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80 p-4 md:p-8 relative">
      {/* Help Button */}
      <HelpDialog gameMode={gameMode} />
      
      <Button
        variant="ghost"
        size="icon"
        onClick={() => navigate("/")}
        className="absolute top-4 left-4 neon-cyan z-10"
      >
        <ArrowLeft className="w-5 h-5" />
      </Button>
      {showRewardSelector && (
        <CardRewardSelector 
          cards={rewardCards} 
          onSelectCards={handleRewardSelection}
        />
      )}
      
      <div className="max-w-7xl mx-auto space-y-6">
        {/* HUD estilo Master Duel */}
        <div className="flex justify-center items-center gap-6 flex-wrap">
          <div className="card-dark px-6 py-3 border-2 border-primary/50 shadow-lg">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Turno</span>
              <span className={`text-lg font-bold px-3 py-1 rounded ${
                currentTurn === "player" 
                  ? "bg-primary/20 text-primary animate-pulse" 
                  : "bg-destructive/20 text-destructive"
              }`}>
                {currentTurn === "player" ? "SEU" : "INIMIGO"}
              </span>
            </div>
          </div>
          
          <div className="card-dark px-6 py-3 border-2 border-accent/50 shadow-lg">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Rodada</span>
              <span className="text-lg font-bold text-accent">{roundNumber}</span>
            </div>
          </div>
          
          <div className="card-dark px-6 py-3 border-2 border-secondary/50 shadow-lg animate-glow-pulse">
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Onda</span>
              <span className="text-2xl font-bold neon-cyan">{waveNumber}</span>
            </div>
          </div>
        </div>

        <GameBoard 
          hand={hand}
          board={board}
          enemyBoard={enemyBoard}
          playerHP={playerHP}
          enemyHP={enemyHP}
          graveyard={graveyard}
          enemyGraveyard={enemyGraveyard}
          sacrificeMode={sacrificeMode}
          sacrificePot={sacrificePot}
          onPlayCard={handlePlayCard}
          onSacrificeCard={handleSacrificeCard}
          onStartSacrificeForPoints={startSacrificeForPoints}
          onEndTurn={endTurn}
          currentTurn={currentTurn}
          gameMode={gameMode}
          fieldToken={fieldToken}
          waveNumber={waveNumber}
        />
      </div>
    </div>
  );
};

export default Game;
