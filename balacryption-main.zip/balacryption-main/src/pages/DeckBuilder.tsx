import { useState } from "react";
import { Card } from "@/types/card";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { GameCard } from "@/components/GameCard";
import { CREATURE_CARDS } from "@/data/creatures";
import { useToast } from "@/hooks/use-toast";
import { useNavigate } from "react-router-dom";
import { X, Check, Play, ArrowLeft, ChevronLeft, ChevronRight } from "lucide-react";

const DeckBuilder = () => {
  const [selectedCards, setSelectedCards] = useState<Card[]>([]);
  const [sortBy, setSortBy] = useState<"level" | "name" | "type">("level");
  const [currentPage, setCurrentPage] = useState(0);
  const [gameMode, setGameMode] = useState<"normal" | "corruption">("normal");
  const { toast } = useToast();
  const navigate = useNavigate();
  const maxPoints = 30;
  const cardsPerPage = 18;

  const calculatePoints = (cards: Card[]) => {
    return cards.reduce((sum, card) => sum + card.level, 0);
  };

  const currentPoints = calculatePoints(selectedCards);
  const remainingPoints = maxPoints - currentPoints;

  const sortedCreatures = [...CREATURE_CARDS].sort((a, b) => {
    if (sortBy === "level") return a.level - b.level;
    if (sortBy === "name") return a.name.localeCompare(b.name);
    if (sortBy === "type") return a.type.localeCompare(b.type);
    return 0;
  });

  const totalPages = Math.ceil(sortedCreatures.length / cardsPerPage);
  const startIndex = currentPage * cardsPerPage;
  const endIndex = startIndex + cardsPerPage;
  const currentPageCards = sortedCreatures.slice(startIndex, endIndex);

  const handleCardClick = (card: Card) => {
    const cardInDeck = selectedCards.find(c => c.name === card.name);
    
    if (cardInDeck) {
      setSelectedCards(prev => prev.filter(c => c.name !== card.name));
      toast({ 
        title: "Carta Removida", 
        description: `${card.name} foi removida do deck`,
        duration: 1500
      });
    } else {
      if (currentPoints + card.level > maxPoints) {
        toast({ 
          title: "Limite de Pontos Excedido", 
          description: `Você precisa de ${card.level} pontos, mas só tem ${remainingPoints} disponíveis`,
          variant: "destructive",
          duration: 2000
        });
        return;
      }

      setSelectedCards(prev => [...prev, { ...card, id: `${card.name}-${Date.now()}` }]);
      toast({ 
        title: "Carta Adicionada", 
        description: `${card.name} adicionada ao deck (${card.level} pts)`,
        duration: 1500
      });
    }
  };

  const handleStartGame = () => {
    if (selectedCards.length < 10) {
      toast({ 
        title: "Deck Incompleto", 
        description: `Você precisa de pelo menos 10 cartas. Faltam ${10 - selectedCards.length}`,
        variant: "destructive"
      });
      return;
    }

    // Salva o deck e navega para o jogo com o modo selecionado
    localStorage.setItem("customDeck", JSON.stringify(selectedCards));
    navigate(`/game?mode=${gameMode === "corruption" ? "corruption-custom" : "custom"}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-background/80 p-4">
      <div className="card-dark max-w-7xl mx-auto max-h-[95vh] flex flex-col">
        <div className="p-4 border-b border-primary/20">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-4">
              <Button variant="ghost" size="icon" onClick={() => navigate("/")}>
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <div>
                <h2 className="text-2xl font-bold neon-cyan">CONSTRUIR DECK</h2>
                <p className="text-sm text-muted-foreground">
                  Escolha pelo menos 10 cartas. Cada carta vale pontos igual ao seu nível.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <span className="text-sm font-mono">Modo:</span>
                <Button 
                  variant={gameMode === "normal" ? "default" : "outline"} 
                  size="sm"
                  onClick={() => setGameMode("normal")}
                  className={gameMode === "normal" ? "animate-glow-pulse" : ""}
                >
                  BALA
                </Button>
                <Button 
                  variant={gameMode === "corruption" ? "default" : "outline"} 
                  size="sm"
                  onClick={() => setGameMode("corruption")}
                  className={gameMode === "corruption" ? "neon-magenta" : ""}
                >
                  CRÝPTION
                </Button>
              </div>
              
              <div className="flex items-center gap-2 border-l border-primary/20 pl-4">
                <span className="text-sm font-mono">Ordenar:</span>
                <Button 
                  variant={sortBy === "level" ? "default" : "outline"} 
                  size="sm"
                  onClick={() => setSortBy("level")}
                >
                  Nível
                </Button>
                <Button 
                  variant={sortBy === "name" ? "default" : "outline"} 
                  size="sm"
                  onClick={() => setSortBy("name")}
                >
                  Nome
                </Button>
                <Button 
                  variant={sortBy === "type" ? "default" : "outline"} 
                  size="sm"
                  onClick={() => setSortBy("type")}
                >
                  Tipo
                </Button>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Pontos</div>
                <div className="text-lg font-bold">
                  <span className={remainingPoints < 0 ? "text-destructive" : "text-primary"}>
                    {currentPoints}
                  </span>
                  <span className="text-muted-foreground"> / {maxPoints}</span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-muted-foreground">Cartas</div>
                <div className="text-lg font-bold">
                  <span className={selectedCards.length < 10 ? "text-warning" : "text-primary"}>
                    {selectedCards.length}
                  </span>
                  <span className="text-muted-foreground"> / mín 10</span>
                </div>
              </div>
              <Button 
                onClick={handleStartGame}
                disabled={selectedCards.length < 10 || currentPoints > maxPoints}
                size="lg"
                className="neon-cyan"
              >
                <Play className="w-4 h-4 mr-2" />
                Iniciar Batalha
              </Button>
            </div>
          </div>
        </div>

        <div className="flex-1 p-4 flex flex-col">
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3 flex-1">
            {currentPageCards.map((card, index) => {
              const cardKey = `${card.name}-${index}`;
              const isSelected = selectedCards.some(c => c.name === card.name);
              const canAdd = currentPoints + card.level <= maxPoints;
              
              return (
                <div 
                  key={cardKey}
                  className="relative cursor-pointer transition-transform hover:scale-105"
                  onClick={() => handleCardClick({ ...card, id: cardKey })}
                >
                  <div className={`relative ${isSelected ? "ring-2 ring-primary" : ""} ${!canAdd && !isSelected ? "opacity-50" : ""}`}>
                    <GameCard card={{ ...card, id: cardKey }} />
                    {isSelected && (
                      <div className="absolute top-1 right-1 bg-primary rounded-full p-1">
                        <Check className="w-3 h-3 text-primary-foreground" />
                      </div>
                    )}
                    {!canAdd && !isSelected && (
                      <div className="absolute inset-0 bg-background/80 flex items-center justify-center rounded-lg">
                        <span className="text-xs font-bold text-destructive">
                          Sem Pontos
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="text-center mt-1">
                    <span className="text-xs text-muted-foreground">{card.level} pts</span>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-center gap-4 mt-4 pt-4 border-t border-primary/20">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentPage(prev => Math.max(0, prev - 1))}
              disabled={currentPage === 0}
            >
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <span className="text-sm font-mono">
              Página {currentPage + 1} / {totalPages}
            </span>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setCurrentPage(prev => Math.min(totalPages - 1, prev + 1))}
              disabled={currentPage === totalPages - 1}
            >
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeckBuilder;
