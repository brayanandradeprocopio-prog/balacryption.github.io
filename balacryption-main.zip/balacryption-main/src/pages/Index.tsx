import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";

const Index = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex items-center justify-center p-8">
      <div className="max-w-2xl w-full space-y-8 text-center">
        <div className="space-y-4">
          <h1 className="text-6xl md:text-7xl font-bold tracking-wider">
            <span className="neon-cyan">BALA</span>
            <span className="neon-magenta">CRÝP</span>
            <span className="text-accent">TION</span>
          </h1>
          <p className="text-xl text-muted-foreground font-mono animate-flicker">
            "Quando a sorte encontra a escuridão"
          </p>
        </div>

        <div className="card-dark border-2 border-primary/30 p-8 space-y-4">
          <p className="text-foreground/80 leading-relaxed">
            Um jogo de cartas colecionáveis onde criaturas sombrias batalham em um tabuleiro 4x2.
            Sacrifique cartas, invoque poderes proibidos, e domine o abismo.
          </p>
        </div>

        <div className="flex gap-4 justify-center flex-wrap animate-slide-in">
          <Button onClick={() => navigate("/game")} variant="outline" size="lg" className="animate-glow-pulse">
            BALA
          </Button>
          <Button onClick={() => navigate("/deck-builder")} variant="outline" size="lg" className="neon-magenta animate-float">
            CRÝPTION
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Index;
