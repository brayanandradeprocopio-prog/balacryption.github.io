import { Card } from "@/types/card";
import { Card as UICard } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sword, Shield, Star } from "lucide-react";
import { cardImages } from "@/components/CardImages";

interface GameCardProps {
  card: Card;
  onClick?: () => void;
  onRightClick?: () => void;
  fullWidth?: boolean; // Para cartas no campo ocuparem slot inteiro
}

const typeColors: Record<string, string> = {
  fire: "bg-orange-600 text-white",
  water: "bg-blue-600 text-white",
  plant: "bg-green-600 text-white",
  shadow: "bg-purple-900 text-white",
  light: "bg-yellow-500 text-black",
  electric: "bg-yellow-400 text-black",
  ice: "bg-cyan-500 text-white",
  poison: "bg-purple-700 text-white",
  metal: "bg-gray-500 text-white",
  spirit: "bg-pink-500 text-white"
};

const typeBorders: Record<string, string> = {
  fire: "border-orange-700",
  water: "border-blue-700",
  plant: "border-green-700",
  shadow: "border-purple-950",
  light: "border-yellow-600",
  electric: "border-yellow-500",
  ice: "border-cyan-600",
  poison: "border-purple-800",
  metal: "border-gray-600",
  spirit: "border-pink-600"
};

const rarityColors: Record<string, string> = {
  common: "bg-gray-600 border-gray-700",
  rare: "bg-blue-600 border-blue-700",
  epic: "bg-purple-600 border-purple-700",
  legendary: "bg-orange-600 border-orange-700",
  cursed: "bg-red-900 border-red-950"
};

const rarityGlow: Record<string, string> = {
  common: "",
  rare: "shadow-[0_0_8px_rgba(59,130,246,0.5)]",
  epic: "shadow-[0_0_8px_rgba(168,85,247,0.5)]",
  legendary: "shadow-[0_0_12px_rgba(234,88,12,0.6)]",
  cursed: "shadow-[0_0_12px_rgba(127,29,29,0.8)]"
};

export const GameCard = ({ card, onClick, onRightClick, fullWidth = false }: GameCardProps) => {
  const handleContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    onRightClick?.();
  };

  return (
    <div 
      className={`pixel-card card-hover ${fullWidth ? 'w-full' : 'w-[120px]'} cursor-pointer relative ${rarityGlow[card.rarity]} animate-fade-in`}
      onClick={onClick}
      onContextMenu={handleContextMenu}
    >
      {/* Header com tipo */}
      <div className={`${typeColors[card.type]} ${typeBorders[card.type]} border-b-2 p-1 flex justify-between items-center`}>
        <span className="text-[6px] font-bold uppercase tracking-wider">{card.type}</span>
        <div className={`${rarityColors[card.rarity]} border px-1 py-0.5 text-[7px] font-bold`}>
          ★{card.level}
        </div>
      </div>

      {/* Corpo da carta */}
      <div className="p-2 bg-gradient-to-b from-card to-muted/20 space-y-2">
        {/* Nome */}
        <h4 className="font-bold text-[8px] leading-tight pixel-text text-center border-b border-dashed border-border pb-1">
          {card.name}
        </h4>

        {/* Arte da carta */}
        <div className="relative aspect-square bg-muted/30 border border-border flex items-center justify-center overflow-hidden animate-glow-pulse">
          {cardImages[card.name] ? (
            <img 
              src={cardImages[card.name]} 
              alt={card.name}
              className="w-full h-full object-contain animate-fade-in hover:animate-float"
              style={{ imageRendering: 'pixelated' }}
            />
          ) : (
            <div className="text-2xl opacity-50">⬛</div>
          )}
          <div className={`absolute top-0.5 right-0.5 ${rarityColors[card.rarity]} border px-1 py-0.5 text-[6px] animate-slide-in`}>
            {card.rarity.toUpperCase()}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-1 text-[8px]">
          <div className="bg-red-900/50 border border-red-700 p-0.5 flex flex-col items-center">
            <Sword className="w-2 h-2 mb-0.5" />
            <span className="font-bold">{card.attack}</span>
          </div>
          <div className="bg-blue-900/50 border border-blue-700 p-0.5 flex flex-col items-center">
            <Shield className="w-2 h-2 mb-0.5" />
            <span className="font-bold">{card.defense}</span>
          </div>
          {card.cost > 0 && (
            <div className="bg-yellow-900/50 border border-yellow-700 p-0.5 flex flex-col items-center">
              <Star className="w-2 h-2 mb-0.5" />
              <span className="font-bold">{card.cost}</span>
            </div>
          )}
        </div>

        {/* Efeito */}
        {card.effects.length > 0 && (
          <div className="bg-background/50 border border-dashed border-border p-1 text-[6px] leading-tight min-h-[32px]">
            {card.effects[0].description}
          </div>
        )}
      </div>

      {/* Borda inferior decorativa */}
      <div className={`h-1 ${typeColors[card.type]} ${typeBorders[card.type]} border-t-2`} />
    </div>
  );
};
