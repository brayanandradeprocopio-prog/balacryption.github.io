import { Card } from "@/types/card";
import { Card as UICard } from "@/components/ui/card";
import { Skull } from "lucide-react";
import { GameCard } from "./GameCard";
import { ScrollArea } from "@/components/ui/scroll-area";

interface GraveyardProps {
  cards: Card[];
  isPlayer: boolean;
}

export const Graveyard = ({ cards, isPlayer }: GraveyardProps) => {
  if (cards.length === 0) return null;

  return (
    <div className={`fixed ${isPlayer ? "bottom-4 left-4" : "top-4 right-4"} z-10`}>
      <UICard className="card-dark p-3 w-48 border-destructive/50 animate-fade-in">
        <div className="flex items-center gap-2 mb-2">
          <Skull className="w-4 h-4 text-destructive" />
          <h3 className="text-xs font-bold text-destructive">
            {isPlayer ? "Seu " : ""}Cemitério ({cards.length})
          </h3>
        </div>
        <ScrollArea className="h-32">
          <div className="space-y-1">
            {cards.slice(-3).map((card, index) => (
              <div key={`grave-${card.id}-${index}`} className="text-xs opacity-70">
                <div className="flex items-center gap-1">
                  <span className="text-destructive">☠️</span>
                  <span>{card.name}</span>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </UICard>
    </div>
  );
};
