import { Card, FieldToken } from "@/types/card";
import { GameCard } from "@/components/GameCard";
import { FieldToken as FieldTokenComponent } from "@/components/FieldToken";
import { Card as UICard } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Heart, Skull, ArrowUpDown } from "lucide-react";
import { useState, useEffect } from "react";
import { getPlayerAvatar, getEnemyAvatar } from "@/components/AvatarImages";

interface GameBoardProps {
  hand: Card[];
  board: Card[];
  enemyBoard: Card[];
  playerHP: number;
  enemyHP: number;
  graveyard: Card[];
  enemyGraveyard: Card[];
  sacrificeMode: {
    active: boolean;
    cardToPlay: Card | null;
    selectedSacrifices: string[];
    required: number;
    type: "invoke" | "store";
  };
  sacrificePot: number;
  onPlayCard: (cardId: string) => void;
  onSacrificeCard: (cardId: string, fromHand?: boolean) => void;
  onStartSacrificeForPoints: () => void;
  onEndTurn: () => void;
  currentTurn: "player" | "enemy";
  gameMode?: "normal" | "corruption";
  fieldToken?: FieldToken | null;
  waveNumber?: number;
}

export const GameBoard = ({ 
  hand, 
  board, 
  enemyBoard,
  playerHP,
  enemyHP,
  graveyard,
  enemyGraveyard,
  sacrificeMode,
  sacrificePot,
  onPlayCard, 
  onSacrificeCard,
  onStartSacrificeForPoints,
  onEndTurn,
  currentTurn,
  gameMode = "normal",
  fieldToken = null,
  waveNumber = 1
}: GameBoardProps) => {
  const [sortedHand, setSortedHand] = useState<Card[]>(hand);
  const [sortType, setSortType] = useState<"level" | "rarity" | "attack" | "defense">("level");

  const rarityOrder = { common: 0, rare: 1, epic: 2, legendary: 3, cursed: 4 };

  const sortHand = (type: "level" | "rarity" | "attack" | "defense") => {
    setSortType(type);
    const sorted = [...hand].sort((a, b) => {
      if (type === "level") return b.level - a.level;
      if (type === "rarity") return rarityOrder[b.rarity] - rarityOrder[a.rarity];
      if (type === "attack") return b.attack - a.attack;
      if (type === "defense") return b.defense - a.defense;
      return 0;
    });
    setSortedHand(sorted);
  };

  // Atualiza a mão ordenada quando hand muda
  useEffect(() => {
    sortHand(sortType);
  }, [hand]);

  return (
    <div className="space-y-3 py-2">

      {/* Sacrifice Mode Banner */}
      {sacrificeMode.active && (
        <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-20 animate-fade-in">
          <div className="card-dark p-6 border-4 border-destructive animate-pulse">
            <div className="text-center space-y-3">
              <Skull className="w-12 h-12 text-destructive mx-auto" />
              <h2 className="text-2xl font-bold text-destructive">MODO SACRIFÍCIO</h2>
              <p className="text-lg">
                Selecione {sacrificeMode.required - sacrificeMode.selectedSacrifices.length} carta(s) do campo para sacrificar
              </p>
              <p className="text-sm text-muted-foreground">
                Para invocar: {sacrificeMode.cardToPlay?.name}
              </p>
              {sacrificeMode.selectedSacrifices.length > 0 && (
                <p className="text-sm text-primary">
                  ✓ {sacrificeMode.selectedSacrifices.length}/{sacrificeMode.required} selecionadas
                </p>
              )}
            </div>
          </div>
        </div>
      )}
      {/* Enemy HP, Avatar, Graveyard & Field Token - Master Duel Style */}
      <div className="flex justify-center gap-4 flex-wrap items-center">
        {/* Enemy Avatar */}
        <div className="w-16 h-16 rounded-full border-2 border-destructive/50 overflow-hidden flex-shrink-0">
          <img 
            src={getEnemyAvatar(waveNumber)} 
            alt="Enemy"
            className="w-full h-full object-cover"
            style={{ imageRendering: 'pixelated' }}
          />
        </div>

        <UICard className="card-dark p-4 border-2 border-destructive/50 shadow-[0_0_15px_rgba(239,68,68,0.3)]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-destructive/20 flex items-center justify-center animate-pulse">
              <Skull className="w-6 h-6 text-destructive" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-destructive uppercase tracking-wider">HP Inimigo</h3>
              <div className="flex items-center gap-2 mt-1">
                <div className="relative w-32 h-2 bg-background rounded-full overflow-hidden border border-destructive/50">
                  <div 
                    className="absolute inset-0 bg-gradient-to-r from-red-600 to-red-400 transition-all duration-500"
                    style={{ width: `${(enemyHP / 20) * 100}%` }}
                  />
                </div>
                <span className="text-xl font-bold text-destructive">{enemyHP}</span>
              </div>
            </div>
          </div>
        </UICard>

        {/* Field Token - Only in Bala Mode */}
        {gameMode === "normal" && fieldToken && (
          <FieldTokenComponent token={fieldToken} />
        )}
      </div>

      {/* Enemy Board Area - Master Duel Style */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold text-destructive uppercase tracking-wider flex items-center gap-2">
          <Skull className="w-4 h-4" />
          Campo Inimigo
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 min-h-[200px] p-3 bg-gradient-to-b from-destructive/5 to-transparent rounded-lg border border-destructive/20">
          {enemyBoard.map((card, index) => (
            <div key={card.id} className="w-full animate-scale-in">
              <GameCard card={card} fullWidth={true} />
            </div>
          ))}
          {Array.from({ length: Math.max(0, 4 - enemyBoard.length) }).map((_, i) => (
            <div 
              key={`enemy-empty-${i}`}
              className="border-2 border-dashed border-destructive/30 rounded-lg flex items-center justify-center text-muted-foreground text-xs hover:border-destructive/50 transition-colors min-h-[180px]"
            >
              Slot {i + enemyBoard.length + 1}
            </div>
          ))}
        </div>
      </div>


      {/* Combat indicator lines */}
      <div className="flex justify-center">
        <div className="w-full max-w-4xl h-8 flex items-center justify-center">
          <div className="text-xs text-muted-foreground">↕ Cartas atacam diretamente na posição correspondente ↕</div>
        </div>
      </div>

      {/* Player Board Area - Master Duel Style */}
      <div className="space-y-2">
        <h3 className="text-xs font-bold text-primary uppercase tracking-wider flex items-center gap-2">
          <Heart className="w-4 h-4" />
          Seu Campo (máx 4)
          {sacrificeMode.active && <span className="text-destructive ml-2 animate-pulse">← Clique para sacrificar</span>}
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 min-h-[200px] p-3 bg-gradient-to-b from-primary/5 to-transparent rounded-lg border border-primary/20">
          {board.map((card) => (
            <div 
              key={card.id} 
              className={`
                w-full transition-all duration-300 animate-scale-in
                ${sacrificeMode.active ? 'cursor-pointer hover:scale-105' : ''}
                ${sacrificeMode.selectedSacrifices.includes(card.id) ? 'ring-4 ring-destructive animate-pulse' : ''}
                ${card.isSacrificing ? 'animate-fade-out opacity-0 scale-95' : ''}
              `}
              onClick={() => sacrificeMode.active && sacrificeMode.type === "store" && onSacrificeCard(card.id, false)}
            >
              <GameCard card={card} fullWidth={true} />
              {sacrificeMode.selectedSacrifices.includes(card.id) && (
                <div className="absolute inset-0 flex items-center justify-center bg-destructive/30 rounded-lg">
                  <Skull className="w-8 h-8 text-destructive animate-bounce" />
                </div>
              )}
            </div>
          ))}
          {Array.from({ length: Math.max(0, 4 - board.length) }).map((_, i) => (
            <div 
              key={`empty-${i}`}
              className="border-2 border-dashed border-primary/30 rounded-lg flex items-center justify-center text-muted-foreground text-xs hover:border-primary/50 transition-colors min-h-[180px]"
            >
              Slot {i + board.length + 1}
            </div>
          ))}
        </div>
      </div>

      {/* Player HP, Avatar, Graveyard, Sacrifice Pot & End Turn - Master Duel Style */}
      <div className="flex justify-center gap-4 flex-wrap items-center">
        {/* Player Avatar - Random element */}
        <div className="w-16 h-16 rounded-full border-2 border-primary/50 overflow-hidden flex-shrink-0">
          <img 
            src={getPlayerAvatar("fire")} 
            alt="Player"
            className="w-full h-full object-cover"
            style={{ imageRendering: 'pixelated' }}
          />
        </div>

        <UICard className="card-dark p-4 border-2 border-primary/50 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center animate-pulse">
              <Heart className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-primary uppercase tracking-wider">Seu HP</h3>
              <div className="flex items-center gap-2 mt-1">
                <div className="relative w-32 h-2 bg-background rounded-full overflow-hidden border border-primary/50">
                  <div 
                    className="absolute inset-0 bg-gradient-to-r from-cyan-600 to-cyan-400 transition-all duration-500 shadow-[0_0_10px_rgba(6,182,212,0.5)]"
                    style={{ width: `${(playerHP / 20) * 100}%` }}
                  />
                </div>
                <span className="text-xl font-bold text-primary">{playerHP}</span>
              </div>
            </div>
          </div>
        </UICard>

        {/* Sacrifice Pot */}
        <UICard className="card-dark p-4 border-2 border-purple-500/50 shadow-[0_0_15px_rgba(168,85,247,0.3)]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center">
              <Skull className="w-6 h-6 text-purple-400" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-purple-300 uppercase tracking-wider">Pote de Sacrifício</h3>
              <div className="flex items-center gap-2 mt-1">
                <div className="flex gap-1">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <div 
                      key={i} 
                      className={`w-4 h-4 rounded-sm border transition-all ${
                        i < sacrificePot 
                          ? 'bg-purple-500 border-purple-400 shadow-[0_0_8px_rgba(168,85,247,0.6)]' 
                          : 'bg-background border-purple-500/30'
                      }`}
                    />
                  ))}
                </div>
                <span className="text-lg font-bold text-purple-300">{sacrificePot}/5</span>
              </div>
            </div>
          </div>
        </UICard>
        
        {graveyard.length > 0 && (
          <UICard className="card-dark p-3 border border-primary/30">
            <div className="flex items-center gap-2 mb-2">
              <Skull className="w-4 h-4 text-primary" />
              <h3 className="text-xs font-bold uppercase tracking-wider">Cemitério ({graveyard.length})</h3>
            </div>
            <div className="space-y-1 max-h-20 overflow-y-auto text-[10px]">
              {graveyard.slice(-3).reverse().map((card, index) => (
                <div key={`grave-${card.id}-${index}`} className="opacity-70 flex items-center gap-1">
                  <span className="text-primary">☠️</span>
                  <span className="truncate">{card.name}</span>
                </div>
              ))}
            </div>
          </UICard>
        )}
        
        {currentTurn === "player" && (
          <>
            <Button 
              onClick={onStartSacrificeForPoints}
              disabled={sacrificePot >= 5}
              variant="outline" 
              className="border-2 border-purple-500 self-center px-6 py-6 text-base font-bold hover:bg-purple-500/20 hover:scale-105 transition-all shadow-lg disabled:opacity-50"
            >
              <Skull className="w-5 h-5 mr-2" />
              Sacrificar (+1 ponto)
            </Button>
            
            <Button 
              onClick={onEndTurn} 
              variant="outline" 
              className="border-2 border-primary self-center px-6 py-6 text-base font-bold hover:bg-primary/20 hover:scale-105 transition-all shadow-lg animate-glow-pulse"
            >
              Finalizar Turno
            </Button>
          </>
        )}
      </div>

      {/* Player Hand */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-foreground">
            Sua Mão 
            {currentTurn === "enemy" && <span className="text-muted-foreground ml-2">(Aguarde seu turno)</span>}
            {sacrificeMode.active && <span className="text-destructive ml-2">(Modo Sacrifício Ativo - Selecione do campo)</span>}
          </h3>
          <div className="flex gap-1">
            <Button 
              size="sm" 
              variant={sortType === "level" ? "default" : "outline"}
              onClick={() => sortHand("level")}
              className="text-[10px] h-6 px-2"
            >
              <ArrowUpDown className="w-3 h-3 mr-1" />
              Nível
            </Button>
            <Button 
              size="sm" 
              variant={sortType === "rarity" ? "default" : "outline"}
              onClick={() => sortHand("rarity")}
              className="text-[10px] h-6 px-2"
            >
              <ArrowUpDown className="w-3 h-3 mr-1" />
              Raridade
            </Button>
            <Button 
              size="sm" 
              variant={sortType === "attack" ? "default" : "outline"}
              onClick={() => sortHand("attack")}
              className="text-[10px] h-6 px-2"
            >
              <ArrowUpDown className="w-3 h-3 mr-1" />
              ATK
            </Button>
            <Button 
              size="sm" 
              variant={sortType === "defense" ? "default" : "outline"}
              onClick={() => sortHand("defense")}
              className="text-[10px] h-6 px-2"
            >
              <ArrowUpDown className="w-3 h-3 mr-1" />
              DEF
            </Button>
          </div>
        </div>
        <div className="flex gap-2 overflow-x-auto pb-2">
          {sortedHand.map((card) => (
            <div 
              key={card.id} 
              className={`flex-shrink-0 ${sacrificeMode.active && sacrificeMode.type === "store" ? 'cursor-pointer hover:scale-105 transition-transform' : ''}`}
              onClick={() => sacrificeMode.active && sacrificeMode.type === "store" && onSacrificeCard(card.id, true)}
            >
              <GameCard 
                card={card}
                fullWidth={false}
                onClick={() => !sacrificeMode.active && currentTurn === "player" && board.length < 4 && onPlayCard(card.id)}
              />
              {card.cost > 0 && (
                <div className="text-center mt-1">
                  <span className="text-[9px] bg-destructive/20 px-1.5 py-0.5 rounded">
                    ☠️ Nv{card.level} ({card.cost})
                  </span>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
