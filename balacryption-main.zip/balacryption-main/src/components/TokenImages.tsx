import crystalPurple from "@/assets/tokens/crystal-purple.png";
import crystalIce1 from "@/assets/tokens/crystal-ice-1.png";
import crystalIce2 from "@/assets/tokens/crystal-ice-2.png";
import crystalIce3 from "@/assets/tokens/crystal-ice-3.png";
import crystalFire1 from "@/assets/tokens/crystal-fire-1.png";
import crystalFire2 from "@/assets/tokens/crystal-fire-2.png";
import crystalFire3 from "@/assets/tokens/crystal-fire-3.png";
import crystalNature1 from "@/assets/tokens/crystal-nature-1.png";
import crystalNature2 from "@/assets/tokens/crystal-nature-2.png";
import crystalNature3 from "@/assets/tokens/crystal-nature-3.png";
import crystalLight1 from "@/assets/tokens/crystal-light-1.png";
import crystalLight2 from "@/assets/tokens/crystal-light-2.png";
import crystalLight3 from "@/assets/tokens/crystal-light-3.png";
import crystalShadow1 from "@/assets/tokens/crystal-shadow-1.png";
import crystalShadow2 from "@/assets/tokens/crystal-shadow-2.png";
import crystalShadow3 from "@/assets/tokens/crystal-shadow-3.png";
import crystalElectric1 from "@/assets/tokens/crystal-electric-1.png";
import crystalElectric2 from "@/assets/tokens/crystal-electric-2.png";
import crystalElectric3 from "@/assets/tokens/crystal-electric-3.png";
import crystalPoison1 from "@/assets/tokens/crystal-poison-1.png";
import crystalPoison2 from "@/assets/tokens/crystal-poison-2.png";
import crystalPoison3 from "@/assets/tokens/crystal-poison-3.png";
import crystalWater1 from "@/assets/tokens/crystal-water-1.png";
import crystalWater2 from "@/assets/tokens/crystal-water-2.png";
import crystalWater3 from "@/assets/tokens/crystal-water-3.png";
import { CardType } from "@/types/card";

export const TOKEN_IMAGES_BY_LEVEL: Record<CardType, Record<1 | 2 | 3, string>> = {
  fire: {
    1: crystalFire1,
    2: crystalFire2,
    3: crystalFire3
  },
  water: {
    1: crystalWater1,
    2: crystalWater2,
    3: crystalWater3
  },
  plant: {
    1: crystalNature1,
    2: crystalNature2,
    3: crystalNature3
  },
  shadow: {
    1: crystalShadow1,
    2: crystalShadow2,
    3: crystalShadow3
  },
  light: {
    1: crystalLight1,
    2: crystalLight2,
    3: crystalLight3
  },
  electric: {
    1: crystalElectric1,
    2: crystalElectric2,
    3: crystalElectric3
  },
  ice: {
    1: crystalIce1,
    2: crystalIce2,
    3: crystalIce3
  },
  poison: {
    1: crystalPoison1,
    2: crystalPoison2,
    3: crystalPoison3
  },
  metal: {
    1: crystalPurple,
    2: crystalPurple,
    3: crystalPurple
  },
  spirit: {
    1: crystalPurple,
    2: crystalPurple,
    3: crystalPurple
  },
};

export const getTokenImage = (type?: CardType, level?: 1 | 2 | 3): string => {
  if (!type) return crystalPurple;
  if (!level) return TOKEN_IMAGES_BY_LEVEL[type]?.[1] || crystalPurple;
  return TOKEN_IMAGES_BY_LEVEL[type]?.[level] || crystalPurple;
};
