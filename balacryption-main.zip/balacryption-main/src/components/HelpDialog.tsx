import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { HelpCircle, Sword, Skull, Sparkles, Flame, Droplet, Leaf, Moon, Sun, Zap, Snowflake, Skull as PoisonIcon } from "lucide-react";
import { ScrollArea } from "@/components/ui/scroll-area";

interface HelpDialogProps {
  gameMode: "normal" | "corruption";
}

export const HelpDialog = ({ gameMode }: HelpDialogProps) => {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="icon"
          className="fixed top-4 right-4 z-50 w-12 h-12 rounded-full border-2 border-primary bg-background/80 backdrop-blur-sm hover:bg-primary/20 hover:scale-110 transition-all shadow-lg"
        >
          <HelpCircle className="w-6 h-6 text-primary animate-pulse" />
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] bg-gradient-to-b from-background to-background/80 border-2 border-primary">
        <DialogHeader>
          <DialogTitle className="text-2xl neon-cyan flex items-center gap-2">
            <HelpCircle className="w-6 h-6" />
            {gameMode === "normal" ? "MODO BALA - GUIA" : "MODO CRÝPTION - GUIA"}
          </DialogTitle>
        </DialogHeader>
        
        <ScrollArea className="h-[60vh] pr-4">
          <div className="space-y-6">
            {/* Regras Básicas */}
            <section className="card-dark p-4 space-y-2">
              <h3 className="text-lg font-bold text-primary flex items-center gap-2">
                <Sword className="w-5 h-5" />
                Regras Básicas
              </h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• <strong>Objetivo:</strong> Reduza a vida do oponente a 0 (ambos começam com 20 HP)</li>
                <li>• <strong>Campo 4x2:</strong> Posicione até 4 cartas no seu campo de batalha</li>
                <li>• <strong>Ataque Direto:</strong> Cartas atacam diretamente a posição correspondente</li>
                <li>• <strong>Sistema de Ondas:</strong> Derrote o chefe de cada onda para avançar</li>
                <li>• <strong>Recompensas:</strong> Escolha 3 cartas após cada vitória</li>
              </ul>
            </section>

            {/* Sistema de Sacrifícios */}
            <section className="card-dark p-4 space-y-2">
              <h3 className="text-lg font-bold text-destructive flex items-center gap-2">
                <Skull className="w-5 h-5" />
                Sistema de Sacrifícios
              </h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• <strong>Nível 1:</strong> Podem ser jogadas diretamente (sem custo)</li>
                <li>• <strong>Nível 2+:</strong> Requerem sacrifício de cartas do campo</li>
                <li>• <strong>Custo:</strong> Número ao lado do nível indica quantas cartas sacrificar</li>
                <li>• <strong>Exemplo:</strong> Carta Nv5 (2) = Sacrifique 2 cartas para invocar</li>
              </ul>
            </section>

            {/* Específico do Modo */}
            {gameMode === "normal" ? (
              <section className="card-dark p-4 space-y-2 border-2 border-primary/50">
                <h3 className="text-lg font-bold text-primary flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  Fichas de Campo (BALA)
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• <strong>Ficha Inicial:</strong> Uma ficha ativa desde o início</li>
                  <li>• <strong>Troca a cada 5 ondas:</strong> Novo cristal com efeito diferente</li>
                  <li>• <strong>6 Efeitos de Cristal:</strong></li>
                  <li className="pl-4">
                    <div className="text-xs space-y-1 mt-1">
                      <div>⚔️ <strong>Fraqueza Elemental:</strong> Elemento afetado -2 ATK</div>
                      <div>🛡️ <strong>Armadura Quebrada:</strong> Elemento afetado -2 DEF</div>
                      <div>💀 <strong>Ritual Complexo:</strong> Custo +1 sacrifício para elemento</div>
                      <div>💔 <strong>Drenagem de Vida:</strong> -1 HP/turno se tiver elemento no campo</div>
                      <div>🚫 <strong>Veneno Persistente:</strong> Não pode curar com elemento no campo</div>
                      <div>💥 <strong>Maldição Frágil:</strong> Elemento recebe dobro de dano</div>
                    </div>
                  </li>
                  <li>• <strong>Visual:</strong> Cristal brilhante mostra o tipo afetado</li>
                  <li>• <strong>Estratégia:</strong> Adapte seu deck ao cristal ativo!</li>
                </ul>
              </section>
            ) : (
              <section className="card-dark p-4 space-y-2 border-2 border-secondary/50">
                <h3 className="text-lg font-bold neon-magenta flex items-center gap-2">
                  <Sparkles className="w-5 h-5" />
                  Eventos Aleatórios (CRÝPTION)
                </h3>
                <ul className="space-y-2 text-sm text-muted-foreground">
                  <li>• <strong>60% de chance por turno:</strong> Eventos frequentes e imprevisíveis</li>
                  <li>• <strong>14 eventos diferentes:</strong> Desde bênçãos até maldições</li>
                  <li className="pl-4">
                    <div className="text-xs space-y-1 mt-1">
                      <div>🌟 <strong>Bênção Sombria:</strong> +3 HP</div>
                      <div>⚡ <strong>Relâmpago Caótico:</strong> -2 HP</div>
                      <div>🎴 <strong>Vento Místico:</strong> Recupera carta do cemitério</div>
                      <div>💀 <strong>Ritual Obscuro:</strong> Inimigo invoca criatura</div>
                      <div>✨ <strong>Sorte do Abismo:</strong> Suas criaturas +1/+1</div>
                      <div>🌑 <strong>Maldição Ancestral:</strong> Todos -1 DEF</div>
                      <div>🔥 <strong>Chamas da Corrupção:</strong> Criaturas de fogo sofrem dano</div>
                      <div>💧 <strong>Chuva Purificadora:</strong> Água +2 DEF</div>
                      <div>⚡ <strong>Tempestade Elétrica:</strong> Elétrico inimigo +1 ATK</div>
                      <div>🌿 <strong>Espinhos Venenosos:</strong> Plantas causam dano ao serem atacadas</div>
                      <div>👻 <strong>Portal Espectral:</strong> Ressurreição aleatória</div>
                      <div>❄️ <strong>Nevasca Congelante:</strong> Todos -1 ATK</div>
                      <div>☀️ <strong>Raio de Luz:</strong> Luz cura 2 HP cada</div>
                      <div>🌑 <strong>Eclipse Sombrio:</strong> Sombra inimiga +2/+1</div>
                    </div>
                  </li>
                </ul>
              </section>
            )}

            {/* Tipos Elementais */}
            <section className="card-dark p-4 space-y-3">
              <h3 className="text-lg font-bold text-accent flex items-center gap-2">
                <Flame className="w-5 h-5" />
                Tipos Elementais
              </h3>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="flex items-center gap-2">
                  <Flame className="w-4 h-4 text-red-500" />
                  <span><strong>Fogo:</strong> Ataque agressivo</span>
                </div>
                <div className="flex items-center gap-2">
                  <Droplet className="w-4 h-4 text-blue-500" />
                  <span><strong>Água:</strong> Defesa e cura</span>
                </div>
                <div className="flex items-center gap-2">
                  <Leaf className="w-4 h-4 text-green-500" />
                  <span><strong>Planta:</strong> Crescimento</span>
                </div>
                <div className="flex items-center gap-2">
                  <Moon className="w-4 h-4 text-purple-500" />
                  <span><strong>Sombra:</strong> Stealth</span>
                </div>
                <div className="flex items-center gap-2">
                  <Sun className="w-4 h-4 text-yellow-500" />
                  <span><strong>Luz:</strong> Suporte</span>
                </div>
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-yellow-300" />
                  <span><strong>Elétrico:</strong> Rápido</span>
                </div>
                <div className="flex items-center gap-2">
                  <Snowflake className="w-4 h-4 text-cyan-400" />
                  <span><strong>Gelo:</strong> Controle</span>
                </div>
                <div className="flex items-center gap-2">
                  <PoisonIcon className="w-4 h-4 text-green-400" />
                  <span><strong>Veneno:</strong> DoT</span>
                </div>
              </div>
            </section>

            {/* Dicas Estratégicas */}
            <section className="card-dark p-4 space-y-2">
              <h3 className="text-lg font-bold text-primary flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Dicas Estratégicas
              </h3>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• <strong>Posicionamento:</strong> Coloque suas cartas mais fortes contra as mais fracas do inimigo</li>
                <li>• <strong>Timing:</strong> Guarde cartas fortes para ondas difíceis</li>
                <li>• <strong>Cemitério:</strong> Recupere cartas automaticamente se sua mão tiver menos de 5</li>
                <li>• <strong>Sacrifícios:</strong> Cartas de nível alto podem virar a partida</li>
                <li>• <strong>Elementos:</strong> Diversifique seu deck para se adaptar</li>
              </ul>
            </section>
          </div>
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
};
