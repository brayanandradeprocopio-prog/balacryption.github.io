// Card images mapping
import chamaIniciante from "@/assets/cards/chama-iniciante.png";
import loboDeBrasas from "@/assets/cards/lobo-de-brasas.png";
import dragaoMenor from "@/assets/cards/dragao-menor.png";
import fenixRenascida from "@/assets/cards/fenix-renascida.png";
import senhorDoVulcao from "@/assets/cards/senhor-do-vulcao.png";
import salamandraArdente from "@/assets/cards/salamandra-ardente.png";
import meteoritoVivo from "@/assets/cards/meteorito-vivo.png";
import ifritSombrio from "@/assets/cards/ifrit-sombrio.png";
import cinzasVivas from "@/assets/cards/cinzas-vivas.png";
import titaFlamejante from "@/assets/cards/tita-flamejante.png";
import gotaFlutuante from "@/assets/cards/gota-flutuante.png";
import sereiaCantora from "@/assets/cards/sereia-cantora.png";
import leviataDasProfundezas from "@/assets/cards/leviata-das-profundezas.png";
import maremoto from "@/assets/cards/maremoto.png";
import poseidonCorrompido from "@/assets/cards/poseidon-corrompido.png";
import carangejoDeCristal from "@/assets/cards/caranguejo-de-cristal.png";
import medusaAquatica from "@/assets/cards/medusa-aquatica.png";
import espiritoDoGeiser from "@/assets/cards/espirito-do-geiser.png";
import krakenAnciao from "@/assets/cards/kraken-anciao.png";
import tsunamiVivo from "@/assets/cards/tsunami-vivo.png";
import sementeMagica from "@/assets/cards/semente-magica.png";
import trepadeira from "@/assets/cards/trepadeira-venenosa.png";
import entGuardiao from "@/assets/cards/ent-guardiao.png";
import florCarnivora from "@/assets/cards/flor-carnivora.png";
import maeNatureza from "@/assets/cards/mae-natureza-corrompida.png";
import esporoParasita from "@/assets/cards/esporo-parasita.png";
import arvoreAncia from "@/assets/cards/arvore-ancia.png";
import cogumeloExplosivo from "@/assets/cards/cogumelo-explosivo.png";
import rosaDasSombras from "@/assets/cards/rosa-das-sombras.png";
import hidraVegetal from "@/assets/cards/hidra-vegetal.png";
import sombraRastejante from "@/assets/cards/sombra-rastejante.png";
import assassinoDasBrumas from "@/assets/cards/assassino-das-brumas.png";
import necromante from "@/assets/cards/necromante.png";
import demonioMenor from "@/assets/cards/demonio-menor.png";
import lordeDasTrevas from "@/assets/cards/lorde-das-trevas.png";
import espectroFaminto from "@/assets/cards/espectro-faminto.png";
import vampiroAnciao from "@/assets/cards/vampiro-anciao.png";
import pesadeloVivo from "@/assets/cards/pesadelo-vivo.png";
import ceifadorDeAlmas from "@/assets/cards/ceifador-de-almas.png";
import apocalipseSombrio from "@/assets/cards/apocalipse-sombrio.png";
import raioDeEsperanca from "@/assets/cards/raio-de-esperanca.png";
import paladinoSagrado from "@/assets/cards/paladino-sagrado.png";
import anjoDaGuarda from "@/assets/cards/anjo-da-guarda.png";
import arcanjoVingador from "@/assets/cards/arcanjo-vingador.png";
import deusSolCaido from "@/assets/cards/deus-sol-caido.png";
import faisca from "@/assets/cards/faisca.png";
import raioElemental from "@/assets/cards/raio-elemental.png";
import dragaoEletrico from "@/assets/cards/dragao-eletrico.png";
import thorMecanico from "@/assets/cards/thor-mecanico.png";
import plasmaPrimordial from "@/assets/cards/plasma-primordial.png";
import cristalGelado from "@/assets/cards/cristal-gelado.png";
import loboDoArtico from "@/assets/cards/lobo-do-artico.png";
import yetiAnciao from "@/assets/cards/yeti-anciao.png";
import dragaoDeGelo from "@/assets/cards/dragao-de-gelo.png";
import eraGlacial from "@/assets/cards/era-glacial.png";
import fungoToxico from "@/assets/cards/fungo-toxico.png";
import serpenteVenenosa from "@/assets/cards/serpente-venenosa.png";
import aranhaColossal from "@/assets/cards/aranha-colossal.png";
import hidraVenenosa from "@/assets/cards/hidra-venenosa.png";
import reiDasToxinas from "@/assets/cards/rei-das-toxinas.png";

export const cardImages: Record<string, string> = {
  "Chama Iniciante": chamaIniciante,
  "Lobo de Brasas": loboDeBrasas,
  "Dragão Menor": dragaoMenor,
  "Fênix Renascida": fenixRenascida,
  "Senhor do Vulcão": senhorDoVulcao,
  "Salamandra Ardente": salamandraArdente,
  "Meteorito Vivo": meteoritoVivo,
  "Ifrit Sombrio": ifritSombrio,
  "Cinzas Vivas": cinzasVivas,
  "Titã Flamejante": titaFlamejante,
  "Gota Flutuante": gotaFlutuante,
  "Sereia Cantora": sereiaCantora,
  "Leviatã das Profundezas": leviataDasProfundezas,
  "Maremoto": maremoto,
  "Poseidon Corrompido": poseidonCorrompido,
  "Caranguejo de Cristal": carangejoDeCristal,
  "Medusa Aquática": medusaAquatica,
  "Espírito do Gêiser": espiritoDoGeiser,
  "Kraken Ancião": krakenAnciao,
  "Tsunami Vivo": tsunamiVivo,
  "Semente Mágica": sementeMagica,
  "Trepadeira Venenosa": trepadeira,
  "Ent Guardião": entGuardiao,
  "Flor Carnívora": florCarnivora,
  "Mãe Natureza Corrompida": maeNatureza,
  "Esporo Parasita": esporoParasita,
  "Árvore Anciã": arvoreAncia,
  "Cogumelo Explosivo": cogumeloExplosivo,
  "Rosa das Sombras": rosaDasSombras,
  "Hidra Vegetal": hidraVegetal,
  "Sombra Rastejante": sombraRastejante,
  "Assassino das Brumas": assassinoDasBrumas,
  "Necromante": necromante,
  "Demônio Menor": demonioMenor,
  "Lorde das Trevas": lordeDasTrevas,
  "Espectro Faminto": espectroFaminto,
  "Vampiro Ancião": vampiroAnciao,
  "Pesadelo Vivo": pesadeloVivo,
  "Ceifador de Almas": ceifadorDeAlmas,
  "Apocalipse Sombrio": apocalipseSombrio,
  "Raio de Esperança": raioDeEsperanca,
  "Paladino Sagrado": paladinoSagrado,
  "Anjo da Guarda": anjoDaGuarda,
  "Arcanjo Vingador": arcanjoVingador,
  "Deus Sol Caído": deusSolCaido,
  "Faísca": faisca,
  "Raio Elemental": raioElemental,
  "Dragão Elétrico": dragaoEletrico,
  "Thor Mecânico": thorMecanico,
  "Plasma Primordial": plasmaPrimordial,
  "Cristal Gelado": cristalGelado,
  "Lobo do Ártico": loboDoArtico,
  "Yeti Ancião": yetiAnciao,
  "Dragão de Gelo": dragaoDeGelo,
  "Era Glacial": eraGlacial,
  "Fungo Tóxico": fungoToxico,
  "Serpente Venenosa": serpenteVenenosa,
  "Aranha Colossal": aranhaColossal,
  "Hidra Venenosa": hidraVenenosa,
  "Rei das Toxinas": reiDasToxinas,
};
