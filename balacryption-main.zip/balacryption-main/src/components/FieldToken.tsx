import { FieldToken as FieldTokenType } from "@/types/card";
import { getTokenImage } from "@/components/TokenImages";
import { Sparkles } from "lucide-react";

interface FieldTokenProps {
  token: FieldTokenType | null;
}

export const FieldToken = ({ token }: FieldTokenProps) => {
  if (!token) {
    return (
      <div className="flex flex-col items-center gap-2">
        <div className="w-32 h-32 rounded-full border-2 border-dashed border-muted-foreground/30 flex items-center justify-center">
          <span className="text-xs text-muted-foreground">Ficha de Campo</span>
        </div>
      </div>
    );
  }

  // Extrai o nível do nome do token (ex: "Cristal... Nv.2")
  const levelMatch = token.name.match(/Nv\.(\d)/);
  const tokenLevel = levelMatch ? parseInt(levelMatch[1]) as 1 | 2 | 3 : 1;
  
  const crystalImage = getTokenImage(token.targetElement, tokenLevel);

  return (
    <div className="flex items-center gap-3 animate-fade-in max-w-md">
      <div className="relative w-24 h-24 flex items-center justify-center flex-shrink-0">
        {/* Crystal sprite */}
        <img 
          src={crystalImage} 
          alt={`${token.targetElement || 'mystery'} crystal`}
          className="w-full h-full object-contain animate-float"
          style={{
            imageRendering: 'pixelated',
            filter: 'drop-shadow(0 0 20px rgba(168,85,247,0.6))'
          }}
        />
        
        {/* Rotating glow effect */}
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-purple-500/20 to-transparent animate-spin-slow rounded-full"></div>
      </div>
      
      <div className="bg-background/80 backdrop-blur-sm p-3 rounded border border-purple-500/30 flex-1">
        <p className="text-xs font-bold text-purple-300 mb-1">{token.name}</p>
        <p className="text-[10px] text-muted-foreground leading-tight">{token.description}</p>
      </div>
    </div>
  );
};
