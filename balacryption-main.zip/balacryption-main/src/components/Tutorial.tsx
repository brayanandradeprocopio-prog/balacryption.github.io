import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Sword, Shield, Skull, ArrowRight, Sparkles } from "lucide-react";

interface TutorialProps {
  onComplete: () => void;
  gameMode?: "normal" | "corruption";
}

export const Tutorial = ({ onComplete, gameMode = "normal" }: TutorialProps) => {
  const isBalaMode = gameMode === "normal";
  
  return (
    <div className="fixed inset-0 bg-background/95 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="max-w-4xl w-full space-y-6 animate-fade-in">
        <div className="text-center space-y-2">
          <h1 className="text-4xl md:text-5xl font-bold">
            {isBalaMode ? (
              <span className="animate-glow-pulse">TUTORIAL - MODO BALA</span>
            ) : (
              <span className="neon-magenta">TUTORIAL - MODO CRÝPTION</span>
            )}
          </h1>
          <p className="text-lg text-muted-foreground">
            {isBalaMode 
              ? "Aprenda a dominar o campo de batalha com fichas de campo estratégicas"
              : "Sobreviva aos eventos caóticos e imprevisíveis do abismo"}
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {/* Objetivo */}
          <Card className="card-dark p-6 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                <Sword className="w-6 h-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-primary">Objetivo</h3>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Reduza a vida do oponente a <strong className="text-foreground">ZERO</strong>. Ambos começam com <strong className="text-foreground">20 HP</strong>. 
              Sobreviva e vença múltiplas ondas de inimigos cada vez mais fortes!
            </p>
          </Card>

          {/* Campo 4x2 */}
          <Card className="card-dark p-6 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
                <Shield className="w-6 h-6 text-accent" />
              </div>
              <h3 className="text-xl font-bold text-accent">Campo 4x2</h3>
            </div>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Posicione até <strong className="text-foreground">4 cartas</strong> no seu campo. 
              Cada carta ataca diretamente a posição correspondente do oponente. 
              Pense estrategicamente!
            </p>
          </Card>

          {/* Sacrifícios */}
          <Card className="card-dark p-6 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-destructive/20 flex items-center justify-center">
                <Skull className="w-6 h-6 text-destructive" />
              </div>
              <h3 className="text-xl font-bold text-destructive">Pote de Sacrifício</h3>
            </div>
            <div className="text-sm text-muted-foreground space-y-2">
              <p>Sistema de pontos para invocar cartas poderosas:</p>
              <ul className="space-y-1 pl-4">
                <li>• <strong>Nível 1:</strong> Jogue direto (sem custo)</li>
                <li>• <strong>Nível 2+:</strong> Consome pontos do pote (0-5)</li>
                <li>• Clique em <strong className="text-purple-300">"Sacrificar"</strong> para ganhar +1 ponto</li>
                <li>• Sacrifique cartas da <strong>mão ou campo</strong></li>
              </ul>
            </div>
          </Card>

          {/* Modo Específico */}
          {isBalaMode ? (
            <Card className="card-dark p-6 space-y-3 border-2 border-primary/50">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-primary/20 flex items-center justify-center">
                  <Sparkles className="w-6 h-6 text-primary animate-pulse" />
                </div>
                <h3 className="text-xl font-bold text-primary">Fichas de Campo</h3>
              </div>
              <div className="text-sm text-muted-foreground space-y-2">
                <p>Um cristal místico altera o campo de batalha:</p>
                <ul className="space-y-1 pl-4">
                  <li>• <strong>Ficha inicial</strong> presente desde o começo</li>
                  <li>• <strong>Troca a cada 5 ondas</strong> com novo efeito</li>
                  <li>• Pode <strong>nervar elementos</strong> ou adicionar desvantagens</li>
                  <li>• Adapte sua estratégia ao cristal ativo!</li>
                </ul>
              </div>
            </Card>
          ) : (
            <Card className="card-dark p-6 space-y-3 border-2 border-secondary/50">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center">
                  <Sparkles className="w-6 h-6 neon-magenta animate-pulse" />
                </div>
                <h3 className="text-xl font-bold neon-magenta">Eventos Caóticos</h3>
              </div>
              <div className="text-sm text-muted-foreground space-y-2">
                <p>O abismo é imprevisível e perigoso:</p>
                <ul className="space-y-1 pl-4">
                  <li>• <strong>60% de chance</strong> de evento a cada turno</li>
                  <li>• <strong>14 eventos diferentes:</strong> bênçãos e maldições</li>
                  <li>• Podem curar, danificar, buffar ou debuffar</li>
                  <li>• Adapte-se rapidamente às mudanças!</li>
                </ul>
              </div>
            </Card>
          )}
        </div>

        {/* Dicas Rápidas */}
        <Card className="card-dark p-6 space-y-3">
          <h3 className="text-lg font-bold text-foreground">💡 Dicas Rápidas</h3>
          <div className="grid md:grid-cols-3 gap-3 text-sm text-muted-foreground">
            <div>
              <strong className="text-primary">Posicionamento:</strong> Coloque cartas fortes contra fracas do inimigo
            </div>
            <div>
              <strong className="text-primary">Cemitério:</strong> Cartas retornam automaticamente se mão {'<'} 5
            </div>
            <div>
              <strong className="text-primary">Recompensas:</strong> Escolha 3 cartas após cada vitória
            </div>
          </div>
        </Card>

        <div className="flex justify-center gap-4">
          <Button 
            size="lg" 
            onClick={onComplete}
            className={isBalaMode ? "animate-glow-pulse text-lg px-8 py-6" : "neon-magenta text-lg px-8 py-6"}
          >
            Começar Batalha
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>

        <p className="text-center text-xs text-muted-foreground">
          Pressione ESC para pular o tutorial
        </p>
      </div>
    </div>
  );
};
