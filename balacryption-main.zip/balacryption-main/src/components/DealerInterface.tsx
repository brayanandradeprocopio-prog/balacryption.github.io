import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dice1, Skull, TrendingUp } from "lucide-react";

interface DealerInterfaceProps {
  onAction: (action: string) => void;
}

export const DealerInterface = ({ onAction }: DealerInterfaceProps) => {
  return (
    <Card className="card-dark p-6 border-2 border-primary/30">
      <div className="flex items-center justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-lg font-bold neon-cyan">O Dealer</h2>
          <p className="text-sm text-muted-foreground">Escolha sua próxima jogada...</p>
        </div>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onAction("draw")}
            className="border-primary hover:bg-primary/20"
          >
            <Dice1 className="w-4 h-4 mr-2" />
            Comprar
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => onAction("sacrifice")}
            className="border-destructive hover:bg-destructive/20"
          >
            <Skull className="w-4 h-4 mr-2" />
            Sacrificar
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => onAction("upgrade")}
            className="border-secondary hover:bg-secondary/20"
          >
            <TrendingUp className="w-4 h-4 mr-2" />
            Melhorar
          </Button>
        </div>
      </div>
    </Card>
  );
};
