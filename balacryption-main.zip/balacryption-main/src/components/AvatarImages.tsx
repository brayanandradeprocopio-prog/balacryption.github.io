import playerFire from "@/assets/avatars/player-fire.png";
import playerWater from "@/assets/avatars/player-water.png";
import playerNature from "@/assets/avatars/player-nature.png";
import playerShadow from "@/assets/avatars/player-shadow.png";
import playerLight from "@/assets/avatars/player-light.png";
import playerElectric from "@/assets/avatars/player-electric.png";
import playerIce from "@/assets/avatars/player-ice.png";
import playerPoison from "@/assets/avatars/player-poison.png";

import enemyFire from "@/assets/avatars/enemy-fire.png";
import enemyWater from "@/assets/avatars/enemy-water.png";
import enemyNature from "@/assets/avatars/enemy-nature.png";
import enemyShadow from "@/assets/avatars/enemy-shadow.png";

import { CardType } from "@/types/card";

export const PLAYER_AVATARS: Record<CardType, string> = {
  fire: playerFire,
  water: playerWater,
  plant: playerNature,
  shadow: playerShadow,
  light: playerLight,
  electric: playerElectric,
  ice: playerIce,
  poison: playerPoison,
  metal: playerShadow,
  spirit: playerLight,
};

export const ENEMY_AVATARS: Record<CardType, string> = {
  fire: enemyFire,
  water: enemyWater,
  plant: enemyNature,
  shadow: enemyShadow,
  light: enemyShadow,
  electric: enemyFire,
  ice: enemyWater,
  poison: enemyNature,
  metal: enemyShadow,
  spirit: enemyShadow,
};

export const getPlayerAvatar = (element?: CardType): string => {
  if (!element) return playerFire;
  return PLAYER_AVATARS[element] || playerFire;
};

export const getEnemyAvatar = (waveNumber: number): string => {
  const elements: CardType[] = ["fire", "water", "plant", "shadow"];
  const index = (waveNumber - 1) % elements.length;
  return ENEMY_AVATARS[elements[index]];
};
