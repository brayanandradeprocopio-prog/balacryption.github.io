import { Card } from "@/types/card";
import { GameCard } from "./GameCard";
import { Button } from "./ui/button";
import { useState } from "react";

interface CardRewardSelectorProps {
  cards: Card[];
  onSelectCards: (selectedCards: Card[]) => void;
}

export const CardRewardSelector = ({ cards, onSelectCards }: CardRewardSelectorProps) => {
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const handleCardClick = (cardId: string) => {
    if (selectedIds.includes(cardId)) {
      setSelectedIds(selectedIds.filter(id => id !== cardId));
    } else if (selectedIds.length < 2) {
      setSelectedIds([...selectedIds, cardId]);
    }
  };

  const handleConfirm = () => {
    const selected = cards.filter(card => selectedIds.includes(card.id));
    onSelectCards(selected);
  };

  return (
    <div className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4">
      <div className="bg-background border-2 border-primary rounded-lg p-6 max-w-4xl w-full space-y-4">
        <div className="text-center space-y-2">
          <h2 className="text-2xl font-bold neon-cyan">ESCOLHA SUA RECOMPENSA</h2>
          <p className="text-muted-foreground pixel-text">Selecione 2 cartas ({selectedIds.length}/2)</p>
        </div>

        <div className="flex flex-wrap justify-center gap-4">
          {cards.map((card) => (
            <div
              key={card.id}
              onClick={() => handleCardClick(card.id)}
              className={`cursor-pointer transition-all ${
                selectedIds.includes(card.id) 
                  ? 'ring-4 ring-primary scale-105' 
                  : 'opacity-80 hover:opacity-100'
              }`}
            >
              <GameCard card={card} />
            </div>
          ))}
        </div>

        <div className="flex justify-center">
          <Button 
            onClick={handleConfirm}
            disabled={selectedIds.length !== 2}
            size="lg"
            className="pixel-text"
          >
            Confirmar Seleção
          </Button>
        </div>
      </div>
    </div>
  );
};
