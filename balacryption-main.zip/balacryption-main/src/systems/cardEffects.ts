import { Card } from "@/types/card";

export class CardEffectsSystem {
  static onCardPlayed(card: Card): { effects: string[]; modifiedCard: Card } {
    const effects: string[] = [];
    let modifiedCard = { ...card };

    // Process on_play effects
    card.effects
      .filter(effect => effect.condition === "on_play")
      .forEach(effect => {
        effects.push(effect.description);
        
        // Apply stat modifications
        if (effect.modifier) {
          if (effect.modifier.attack) {
            modifiedCard.attack += effect.modifier.attack;
          }
          if (effect.modifier.defense) {
            modifiedCard.defense += effect.modifier.defense;
          }
        }
      });

    return { effects, modifiedCard };
  }

  static onCardAttack(attacker: Card, defender?: Card): { 
    effects: string[]; 
    modifiedAttacker: Card;
    modifiedDefender?: Card;
  } {
    const effects: string[] = [];
    let modifiedAttacker = { ...attacker };
    let modifiedDefender = defender ? { ...defender } : undefined;

    // Process on_attack effects
    attacker.effects
      .filter(effect => effect.condition === "on_attack")
      .forEach(effect => {
        effects.push(effect.description);
      });

    // Process type advantage effects
    if (defender) {
      attacker.effects
        .filter(effect => 
          effect.condition === "vs_type" && 
          effect.modifier?.targetType === defender.type
        )
        .forEach(effect => {
          if (effect.modifier?.attack) {
            modifiedAttacker.attack += effect.modifier.attack;
            effects.push(`+${effect.modifier.attack} ATK contra ${defender.type}`);
          }
        });
    }

    return { effects, modifiedAttacker, modifiedDefender };
  }

  static onCardDefend(defender: Card, attacker: Card): {
    effects: string[];
    modifiedDefender: Card;
    modifiedAttacker: Card;
  } {
    const effects: string[] = [];
    let modifiedDefender = { ...defender };
    let modifiedAttacker = { ...attacker };

    // Process on_defend effects
    defender.effects
      .filter(effect => effect.condition === "on_defend")
      .forEach(effect => {
        effects.push(effect.description);
      });

    return { effects, modifiedDefender, modifiedAttacker };
  }

  static onCardDeath(card: Card): { effects: string[] } {
    const effects: string[] = [];

    // Process on_death effects
    card.effects
      .filter(effect => effect.condition === "on_death")
      .forEach(effect => {
        effects.push(effect.description);
      });

    return { effects };
  }

  static onStartTurn(cards: Card[]): { effects: string[]; modifiedCards: Card[] } {
    const effects: string[] = [];
    const modifiedCards = cards.map(card => {
      const cardEffects = card.effects.filter(effect => effect.condition === "start_turn");
      
      if (cardEffects.length > 0) {
        let modified = { ...card };
        cardEffects.forEach(effect => {
          effects.push(`${card.name}: ${effect.description}`);
          
          if (effect.modifier) {
            if (effect.modifier.attack) {
              modified.attack += effect.modifier.attack;
            }
            if (effect.modifier.defense) {
              modified.defense += effect.modifier.defense;
            }
          }
        });
        return modified;
      }
      
      return card;
    });

    return { effects, modifiedCards };
  }

  static calculateDamage(attacker: Card, defender?: Card): number {
    let damage = attacker.attack;

    // Apply type advantages
    if (defender) {
      const typeAdvantages = attacker.effects
        .filter(effect => 
          effect.condition === "vs_type" && 
          effect.modifier?.targetType === defender.type &&
          effect.modifier?.attack
        );
      
      typeAdvantages.forEach(effect => {
        if (effect.modifier?.attack) {
          damage += effect.modifier.attack;
        }
      });
    }

    return damage;
  }
}
