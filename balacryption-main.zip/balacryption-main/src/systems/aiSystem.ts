import { Card } from "@/types/card";
import { getRandomCards } from "@/data/creatures";

export class AISystem {
  static generateAIHand(roundNumber: number, waveNumber: number = 1): Card[] {
    // Aumenta a quantidade e qualidade das cartas com base na onda
    const baseCardCount = Math.min(4 + Math.floor(roundNumber / 2), 8);
    const waveBonus = Math.floor(waveNumber / 2);
    const totalCards = Math.min(baseCardCount + waveBonus, 10);
    
    const cards = getRandomCards(totalCards).map((card, index) => {
      // Buff das cartas aumenta com as ondas
      const waveMultiplier = 1 + (waveNumber - 1) * 0.15;
      return {
        ...card,
        id: `ai-card-${Date.now()}-${index}`,
        attack: Math.floor(card.attack * waveMultiplier),
        defense: Math.floor(card.defense * waveMultiplier)
      };
    });
    
    return cards;
  }

  static playCards(hand: Card[], currentBoard: Card[], playerBoard: Card[], waveNumber: number = 1): Card[] {
    const availableSlots = 4 - currentBoard.length;
    if (availableSlots <= 0) return currentBoard;

    // IA adaptativa - fica mais inteligente com as ondas
    const isAdvancedAI = waveNumber >= 2;
    const cardsToPlay: Card[] = [];
    let remainingHand = [...hand];
    let workingBoard = [...currentBoard];
    
    // Estratégia 1: Jogar cartas de nível 1 (gratuitas) primeiro
    const freeCards = remainingHand
      .filter(card => card.cost === 0)
      .sort((a, b) => b.attack - a.attack);
    
    freeCards.slice(0, availableSlots).forEach(card => {
      if (workingBoard.length < 4) {
        cardsToPlay.push(card);
        workingBoard.push(card);
        remainingHand = remainingHand.filter(c => c.id !== card.id);
      }
    });

    // Estratégia 2: IA avançada considera sacrifícios DO CAMPO
    if (isAdvancedAI && workingBoard.length < 4 && workingBoard.length > 0) {
      const highValueCards = remainingHand
        .filter(card => card.cost > 0 && card.cost <= workingBoard.length)
        .sort((a, b) => {
          const valueA = (a.attack + a.defense) / Math.max(a.cost, 1);
          const valueB = (b.attack + b.defense) / Math.max(b.cost, 1);
          return valueB - valueA;
        });

      for (const highCard of highValueCards) {
        if (workingBoard.length < 4 && workingBoard.length >= highCard.cost) {
          // Identifica cartas mais fracas no campo para sacrificar
          const sacrificeableCards = [...workingBoard]
            .sort((a, b) => (a.attack + a.defense) - (b.attack + b.defense))
            .slice(0, highCard.cost);

          if (sacrificeableCards.length === highCard.cost) {
            // Remove cartas sacrificadas do campo de trabalho
            sacrificeableCards.forEach(toSacrifice => {
              workingBoard = workingBoard.filter(c => c.id !== toSacrifice.id);
              // Remove também da lista de cartas a jogar se ainda não foi jogada
              const indexInPlay = cardsToPlay.findIndex(c => c.id === toSacrifice.id);
              if (indexInPlay !== -1) {
                cardsToPlay.splice(indexInPlay, 1);
              }
            });
            
            // Adiciona a carta poderosa
            cardsToPlay.push(highCard);
            workingBoard.push(highCard);
            remainingHand = remainingHand.filter(c => c.id !== highCard.id);
          }
        }
      }
    }

    return workingBoard;
  }

  static evaluateBoard(board: Card[]): number {
    return board.reduce((total, card) => total + card.attack + card.defense, 0);
  }
  
  static calculateThreatLevel(board: Card[]): number {
    if (board.length === 0) return 0;
    const avgPower = board.reduce((sum, card) => sum + card.attack + card.defense, 0) / board.length;
    return avgPower * board.length;
  }
}
