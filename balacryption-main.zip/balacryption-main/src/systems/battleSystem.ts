import { Card } from "@/types/card";

export class BattleSystem {
  static onCardPlayed(card: Card): { effects: string[]; modifiedCard: Card } {
    const effects: string[] = [];
    let modifiedCard = { ...card };

    // Process on_play effects
    card.effects
      .filter(effect => effect.condition === "on_play")
      .forEach(effect => {
        effects.push(`✨ ${effect.description}`);
        
        if (effect.modifier) {
          if (effect.modifier.attack !== undefined) {
            modifiedCard.attack += effect.modifier.attack;
          }
          if (effect.modifier.defense !== undefined) {
            modifiedCard.defense += effect.modifier.defense;
          }
        }
      });

    return { effects, modifiedCard };
  }

  static onCardSacrificed(card: Card): string[] {
    const effects: string[] = [];
    
    card.effects
      .filter(effect => effect.condition === "on_sacrifice")
      .forEach(effect => {
        effects.push(`☠️ ${card.name}: ${effect.description}`);
      });

    return effects;
  }

  static resolveCombat(attackingBoard: Card[], defendingBoard: Card[]): {
    playerDamage: number;
    enemyDamage: number;
    destroyedDefenders: number[];
    destroyedAttackers: number[];
  } {
    let playerDamage = 0;
    let enemyDamage = 0;
    const destroyedDefenders: number[] = [];
    const destroyedAttackers: number[] = [];

    // Fase 1: Combate entre cartas (apenas nas posições com defensores)
    attackingBoard.forEach((attacker, index) => {
      const defender = defendingBoard[index];
      
      if (defender) {
        // Combate carta vs carta
        const attackDamage = this.calculateDamage(attacker, defender);
        const defenderDamage = this.calculateDamage(defender, attacker);
        
        // Defensor recebe dano
        const defenderHealth = defender.defense - attackDamage;
        
        if (defenderHealth <= 0) {
          // Defender é destruído
          destroyedDefenders.push(index);
          // Dano excedente não passa para o jogador - carta foi bloqueada
        }
        
        // Atacante também recebe dano em retorno
        const attackerHealth = attacker.defense - defenderDamage;
        if (attackerHealth <= 0) {
          destroyedAttackers.push(index);
        }
      }
    });

    // Fase 2: Dano direto apenas em slots VAZIOS (sem defensores)
    attackingBoard.forEach((attacker, index) => {
      const defender = defendingBoard[index];
      
      // Atacante só causa dano direto se não houver defensor E não foi destruído
      if (!defender && !destroyedAttackers.includes(index)) {
        const directDamage = attacker.attack;
        playerDamage += directDamage;
      }
    });

    // Contra-ataque dos defensores em slots vazios do atacante
    defendingBoard.forEach((defender, index) => {
      const attacker = attackingBoard[index];
      
      if (!attacker && !destroyedDefenders.includes(index)) {
        const directDamage = defender.attack;
        enemyDamage += directDamage;
      }
    });

    return { playerDamage, enemyDamage, destroyedDefenders, destroyedAttackers };
  }

  static calculateDamage(attacker: Card, defender?: Card): number {
    let damage = attacker.attack;

    if (defender) {
      // Apply type advantages
      const typeAdvantages = attacker.effects
        .filter(effect => 
          effect.condition === "vs_type" && 
          effect.modifier?.targetType === defender.type &&
          effect.modifier?.attack !== undefined
        );
      
      typeAdvantages.forEach(effect => {
        if (effect.modifier?.attack !== undefined) {
          damage += effect.modifier.attack;
        }
      });

      // Apply on_attack effects
      attacker.effects
        .filter(effect => effect.condition === "on_attack")
        .forEach(effect => {
          if (effect.modifier?.attack !== undefined) {
            damage += effect.modifier.attack;
          }
        });
    }

    return Math.max(0, damage);
  }

  static applyStartTurnEffects(cards: Card[]): { effects: string[]; modifiedCards: Card[] } {
    const effects: string[] = [];
    const modifiedCards = cards.map(card => {
      const cardEffects = card.effects.filter(effect => effect.condition === "start_turn");
      
      if (cardEffects.length > 0) {
        let modified = { ...card };
        cardEffects.forEach(effect => {
          effects.push(`⚡ ${card.name}: ${effect.description}`);
          
          if (effect.modifier) {
            if (effect.modifier.attack !== undefined) {
              modified.attack = Math.max(0, modified.attack + effect.modifier.attack);
            }
            if (effect.modifier.defense !== undefined) {
              modified.defense = Math.max(0, modified.defense + effect.modifier.defense);
            }
          }
        });
        return modified;
      }
      
      return card;
    });

    return { effects, modifiedCards };
  }
}
