-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create enum types
CREATE TYPE app_role AS ENUM ('admin', 'player');
CREATE TYPE battle_status AS ENUM ('active', 'player_won', 'opponent_won', 'abandoned');
CREATE TYPE card_type AS ENUM ('fire', 'water', 'plant', 'shadow', 'light', 'electric', 'ice', 'poison', 'metal', 'spirit');
CREATE TYPE card_rarity AS ENUM ('common', 'rare', 'epic', 'legendary', 'cursed');

-- Create profiles table
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username TEXT UNIQUE NOT NULL,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view all profiles"
  ON public.profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON public.profiles FOR UPDATE
  USING (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON public.profiles FOR INSERT
  WITH CHECK (auth.uid() = id);

-- Create user_roles table
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL DEFAULT 'player',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, role)
);

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own roles"
  ON public.user_roles FOR SELECT
  USING (auth.uid() = user_id);

-- Create player_progress table
CREATE TABLE public.player_progress (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  level INTEGER NOT NULL DEFAULT 1,
  experience INTEGER NOT NULL DEFAULT 0,
  wins INTEGER NOT NULL DEFAULT 0,
  losses INTEGER NOT NULL DEFAULT 0,
  unlocked_cards TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  deck_capacity INTEGER NOT NULL DEFAULT 30,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.player_progress ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own progress"
  ON public.player_progress FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own progress"
  ON public.player_progress FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own progress"
  ON public.player_progress FOR UPDATE
  USING (auth.uid() = user_id);

-- Create decks table
CREATE TABLE public.decks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  card_ids TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  is_active BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.decks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own decks"
  ON public.decks FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own decks"
  ON public.decks FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own decks"
  ON public.decks FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own decks"
  ON public.decks FOR DELETE
  USING (auth.uid() = user_id);

-- Create battles table
CREATE TABLE public.battles (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  player_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  opponent_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  is_vs_ai BOOLEAN NOT NULL DEFAULT true,
  status battle_status NOT NULL DEFAULT 'active',
  player_health INTEGER NOT NULL DEFAULT 20,
  opponent_health INTEGER NOT NULL DEFAULT 20,
  current_turn TEXT NOT NULL DEFAULT 'player',
  round_number INTEGER NOT NULL DEFAULT 1,
  player_board JSONB NOT NULL DEFAULT '[]'::JSONB,
  opponent_board JSONB NOT NULL DEFAULT '[]'::JSONB,
  player_hand JSONB NOT NULL DEFAULT '[]'::JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  finished_at TIMESTAMPTZ
);

ALTER TABLE public.battles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own battles"
  ON public.battles FOR SELECT
  USING (auth.uid() = player_id OR auth.uid() = opponent_id);

CREATE POLICY "Users can insert own battles"
  ON public.battles FOR INSERT
  WITH CHECK (auth.uid() = player_id);

CREATE POLICY "Users can update own battles"
  ON public.battles FOR UPDATE
  USING (auth.uid() = player_id OR auth.uid() = opponent_id);

-- Create battle_rounds table
CREATE TABLE public.battle_rounds (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  battle_id UUID NOT NULL REFERENCES public.battles(id) ON DELETE CASCADE,
  round_number INTEGER NOT NULL,
  actions JSONB NOT NULL DEFAULT '[]'::JSONB,
  player_board_state JSONB NOT NULL,
  opponent_board_state JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE public.battle_rounds ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view rounds from own battles"
  ON public.battle_rounds FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM public.battles
      WHERE battles.id = battle_id
      AND (battles.player_id = auth.uid() OR battles.opponent_id = auth.uid())
    )
  );

CREATE POLICY "Users can insert rounds in own battles"
  ON public.battle_rounds FOR INSERT
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.battles
      WHERE battles.id = battle_id
      AND (battles.player_id = auth.uid() OR battles.opponent_id = auth.uid())
    )
  );

-- Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers for updated_at
CREATE TRIGGER update_profiles_updated_at
  BEFORE UPDATE ON public.profiles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_player_progress_updated_at
  BEFORE UPDATE ON public.player_progress
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_decks_updated_at
  BEFORE UPDATE ON public.decks
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_battles_updated_at
  BEFORE UPDATE ON public.battles
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- Create function to handle new user registration
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  -- Insert profile
  INSERT INTO public.profiles (id, username)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', 'Jogador_' || substring(NEW.id::text, 1, 8))
  );
  
  -- Insert default role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, 'player');
  
  -- Insert initial progress with starter cards unlocked
  INSERT INTO public.player_progress (
    user_id,
    level,
    experience,
    unlocked_cards
  )
  VALUES (
    NEW.id,
    1,
    0,
    ARRAY[
      'Chama Iniciante', 'Gota Flutuante', 'Semente Mágica', 
      'Sombra Rastejante', 'Raio de Esperança', 'Faísca',
      'Cristal Gelado', 'Fungo Tóxico'
    ]
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER SET search_path = public;

-- Create trigger for new user
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();